# Proprioception — Your Hidden GPS

*A deep-dive into the body's silent navigation system, why it beats strength for reaction time, and the 4-week reset that rewires your racket awareness at any age.*

*Đi sâu vào hệ định vị thầm lặng của cơ thể, tại sao nó thắng sức mạnh về tốc độ phản xạ, và chương trình 4 tuần tái lập nhận thức vợt ở mọi lứa tuổi.*

---

## A Note From the Coach / Lời Huấn Luyện Viên

Friend, let me tell you something most coaches won't say. You've been training the wrong athlete.

You spend your gym hours chasing strength. You chase a heavier serve, a stronger forehand, a tighter grip. You buy the elastic bands, you do the push-ups, you push the heavier dumbbell. And yes, that matters — but only after the ball is already in your strike zone. The real question is: how did it get there in the first place? The answer is almost never strength. The answer is **proprioception** — your body's hidden GPS, the silent map that tells your brain where your racket is, how fast it's moving, how hard the string-bed is being pushed, and where the sweet spot sits relative to your wrist. Strength is the engine. Proprioception is the steering wheel. And most club players — including you, friend, including me — have been driving with no steering wheel for years.

This deep-dive is about giving the steering wheel back. We will go past the master manual's overview and into the actual wiring: the four sensors that feed your brain, why proprioception beats strength by 20–45 milliseconds on every shot, how to retrain the system in four weeks, and the one quick test you can do tonight to see exactly where you stand. There is a 50+ advantage here that almost nobody talks about — proprioception is the one athletic quality that does **not** decline with age the way strength does. The neural circuits stay plastic. The map can be redrawn. The GPS can be re-tuned.

We are going to redraw yours.

*Anh bạn, để tôi nói với anh điều mà hầu hết HLV không nói. Anh đã tập sai vận động viên.*

*Anh dành hàng giờ ở phòng gym săn sức mạnh. Anh săn cú serve nặng hơn, forehand mạnh hơn, grip chặt hơn. Anh mua dây kháng lực, chống đẩy, đẩy tạ nặng hơn. Vâng, điều đó cần thiết — nhưng chỉ sau khi bóng đã ở trong vùng đánh. Câu hỏi thật là: làm sao nó tới được đó ngay từ đầu? Câu trả lời hầu như không bao giờ là sức mạnh. Câu trả lời là **cảm thụ bản thể** — GPS ẩn của cơ thể, tấm bản đồ thầm lặng báo cho não biết vợt ở đâu, đang di chuyển nhanh cỡ nào, mặt vợt đang chịu lực bao nhiêu, và sweet spot nằm chỗ nào so với cổ tay. Sức mạnh là động cơ. Cảm thụ bản thể là vô-lăng. Và hầu hết người chơi câu lạc bộ — kể cả anh, kể cả tôi — đã lái xe không có vô-lăng nhiều năm rồi.*

*Bản đi sâu này nói về việc trả lại vô-lăng. Chúng ta sẽ đi xa hơn phần tổng quan trong cẩm nang chính, vào tận hệ thống dây dẫn: bốn cảm biến cung cấp dữ liệu cho não, tại sao cảm thụ bản thể thắng sức mạnh 20–45 mili-giây trên mỗi cú đánh, cách tái huấn luyện hệ thống trong bốn tuần, và một bài test nhanh anh có thể làm tối nay để biết mình đang đứng ở đâu. Có một lợi thế 50+ mà hầu như không ai nói tới — cảm thụ bản thể là phẩm chất thể thao duy nhất **không** suy giảm theo tuổi như sức mạnh. Mạch thần kinh vẫn dẻo. Bản đồ có thể vẽ lại. GPS có thể chỉnh lại.*

*Chúng ta sẽ vẽ lại của anh.*

---

## Table of Contents / Mục Lục

| # | English | Tiếng Việt |
|---|---|---|
| 1 | What Proprioception Actually Is — And Why It's the Hidden GPS | Cảm Thụ Bản Thể Thực Sự Là Gì — Và Tại Sao Nó Là GPS Ẩn |
| 2 | The 4 Proprioceptive Inputs Every Tennis Player Must Know | 4 Đầu Vào Cảm Thụ Bản Thể Mà Tay Vợt Nào Cũng Phải Biết |
| 3 | Why Proprioception > Strength for Reaction Time | Tại Sao Cảm Thụ Bản Thể > Sức Mạnh Về Tốc Độ Phản Xạ |
| 4 | The 4-Week Proprioception Reset Program | Chương Trình Tái Lập Cảm Thụ Bản Thể 4 Tuần |
| 5 | The 50+ Advantage — Why This Is the Real Fountain of Youth on Court | Lợi Thế 50+ — Tại Sao Đây Là Suối Nguồn Tươi Trẻ Thật Sự Trên Sân |
| 6 | The Nose-Touch Diagnostic — Test Yourself Tonight | Chẩn Đoán Chạm Mũi — Tự Kiểm Tra Tối Nay |
| 7 | Printable 1-Page Cheat Sheet | Bảng Câu Nhắc 1 Trang In Ra Được |

---

## Chapter 1 — What Proprioception Actually Is / Cảm Thụ Bản Thể Thực Sự Là Gì

| 🇺🇸 English |
| --- |
| **The plain definition:** proprioception is the sense of your body's own position, movement, and force *without* using your eyes. You are using it right now to know where your feet are, how your spine is curved, and how heavy the phone in your hand is — all with your eyes closed. In tennis, it tells you where the racket head is in space, how fast it's moving, and what the string-bed is feeling. |
| **Where the signal comes from:** the data is collected by three families of receptors. **Muscle spindles** (inside the belly of every muscle) measure how long a muscle is and how fast it's being stretched — this is your velocity + joint-angle input. **Golgi tendon organs** (at the muscle-tendon junction) measure how hard the muscle is pulling on its tendon — this is your force input. **Joint receptors** (Ruffini endings, Pacinian corpuscles in the capsule) measure the angle and pressure at each joint. |
| **The Hidden GPS metaphor:** think of it as your body's satellite navigation. The eyes are the dashboard screen — they show you the *map*. Proprioception is the GPS unit underneath, telling you *where you are right now* even when the screen is dark, the road is foggy, or you're moving at 200 km/h. On a tennis court, the screen (vision) goes dark for ~80 ms every time you blink, every time the ball is behind you, every time you turn to track an opponent. The GPS keeps working through all of it. |
| **Why it's "hidden":** because you cannot feel it directly. There is no "proprioception sense" you can point to, like sight or hearing. It runs silently. You only notice it when it fails — when you reach for a cup in the dark and miss, when you stumble on a step you didn't see, when you hit a forehand and the racket feels "dead" in your hand. The silence is exactly why most players never train it. |
| **The racket is part of the body:** with enough training, the brain stops treating the racket as an external object. The 27-inch frame becomes a sensory extension of the forearm. You can feel whether the sweet spot is striking the ball or the throat is. This is called *embodiment* — and it only happens when the proprioceptive signal from the racket is clean, fast, and reliable. |
| **🎯 Master Cue / Câu Nhắc Tổng:** *Proprioception is data. Strength is power. You cannot generate power you cannot aim. Train the data first.* / *Cảm thụ bản thể là dữ liệu. Sức mạnh là công suất. Anh không thể tạo lực mà không ngắm được. Hãy tập dữ liệu trước.* |
| **🧓 50+ Note / Ghi Chú 50+:** proprioception is the one quality that *improves* with deliberate training in older players, while raw strength declines ~1% per year after 50. The asymmetry of loss and gain means the 52-year-old who trains proprioception can out-react the 35-year-old who only lifts weights. / *Cảm thụ bản thể là phẩm chất duy nhất **cải thiện** khi tập có chủ đích ở người lớn tuổi, trong khi sức mạnh thuần giảm ~1% mỗi năm sau 50. Sự bất đối xứng giữa mất và được có nghĩa người 52 tuổi tập cảm thụ bản thể có thể phản xạ nhanh hơn người 35 tuổi chỉ tập tạ.* |

---

## Chapter 2 — The 4 Proprioceptive Inputs / 4 Đầu Vào Cảm Thụ Bản Thể

| 🇺🇸 English |
| --- |
| **Input 1 — Joint Angle (Góc Khớp):** the absolute position of every joint in space. Where is the elbow? At what angle is the shoulder? How bent is the knee? The brain uses joint-angle data to know what kind of shot you are in the middle of — preparation, contact, follow-through. If joint-angle data is fuzzy, you will over-swing on volleys (because you don't trust your elbow position) and under-step on wide balls (because you don't trust your hip angle). |
| **Input 2 — Velocity (Vận Tốc):** the rate of change of joint angle. How fast is the shoulder rotating? How fast is the racket head accelerating toward the ball? Velocity data is what tells the brain "we have time for a full swing" or "we have to compact now." It comes almost entirely from muscle spindles — they are stretch-sensitive, so the faster a muscle is being lengthened, the more they fire. Train velocity and your brain starts auto-selecting compact vs. full swings without you thinking. |
| **Input 3 — Force (Lực):** how much tension is in each muscle and how hard the tendon is being loaded. Force data comes from Golgi tendon organs. This is the only proprioceptive input that overlaps with strength training — but the key difference is *awareness*, not capacity. You can bench 100 kg and still have terrible force-awareness in your forearm. Force-awareness tells you "I am at 70% effort" so you can dial it down to 50% for a drop shot, or up to 90% for a passing shot. Without it, every ball is hit at 100%. |
| **Input 4 — Racket Position (Vị Trí Vợt):** the location of the racket head relative to your hand, your body, and the incoming ball. This is the most tennis-specific input and the one most club players have the worst data on. Your hand knows the grip. Your wrist knows the angle. But the racket head — 27 inches away — has to be tracked through indirect signals: vibration up the frame, torque on the wrist, the way the air feels against the strings. A well-trained player can close their eyes and point to the sweet spot. A poorly-trained player needs to look. |
| **The sound tells you which input is failing:** a mistimed forehand sounds **bộp** (muffled, no resonance) when racket position is off — sweet spot missed by >5 cm. A slice sounds **phập** (soft, swishing) when the angle is right but force is too low. A volley block sounds **bịch** (crisp, dead) when contact is firm but velocity is zero — pure stop. A flat drive sounds **cốc** (sharp, ringing) when everything is aligned: joint angle correct, velocity matched, force appropriate, sweet spot centered. A topspin loop sounds **pực** (heavy, low-pitched thump) when the ball is brushing up the back of the string-bed with massive force. Train your ears to diagnose. |
| **🎯 Master Cue / Câu Nhắc Tổng:** *Four sensors. Four sounds. cốc = everything aligned, bộp = position off, phập = force off, bịch = velocity off, pực = force + spin aligned. Listen before you look.* / *Bốn cảm biến. Bốn âm. cốc = mọi thứ thẳng hàng, bộp = lệch vị trí, phập = lệch lực, bịch = lệch vận tốc, pực = lực + xoáy thẳng hàng. Hãy nghe trước khi nhìn.* |
| **🧓 50+ Note / Ghi Chú 50+:** at 50+, joint-angle receptors (Ruffini endings) degrade slightly, but they can be retrained. The wrist joint — where tennis depends most on fine angle sense — responds particularly well to blind-rally drills. Don't skip the wrist. / *Ở 50+, thụ thể góc khớp (tiểu thể Ruffini) suy giảm nhẹ, nhưng có thể tập lại được. Khớp cổ tay — nơi tennis phụ thuộc nhiều nhất vào cảm giác góc tinh tế — đáp lại đặc biệt tốt với bài tập rally nhắm mắt. Đừng bỏ qua cổ tay.* |

---

## Chapter 3 — Why Proprioception > Strength for Reaction Time / Tại Sao Cảm Thụ Bản Thể > Sức Mạnh Về Tốc Độ Phản Xạ

| 🇺🇸 English |
| --- |
| **The math of a tennis rally:** an 80 km/h drive takes ~350 ms to travel from the opponent's racket to yours. Your brain needs 120–150 ms just to *see* the ball, identify it, and start a voluntary movement plan. That leaves ~200 ms for your body to actually get the racket to the contact zone. Strength cannot buy you those 200 ms. They belong to reflexes — short-latency reflex (SLR, 20–45 ms in the spinal cord) and long-latency reflex (LLR, 50–80 ms through the brainstem). Both run on proprioceptive input. |
| **Strength is power, proprioception is data:** strength determines how much force you can apply *once you have decided to move*. Proprioception determines whether you decide to move in time at all. A player with 50% more strength but 30% worse proprioception will lose to a faster-feeling opponent on every short ball — because by the time the strong player has planned the swing, the ball is past them. |
| **The data-power sequence:** this is the order, in milliseconds: **(1)** proprioceptors detect change → **(2)** signal races to spinal cord and brainstem (proprioception in action) → **(3)** reflex fires correct muscles → **(4)** racket starts moving → **(5)** strength determines how fast and how hard the racket accelerates → **(6)** contact. If step 1 is slow because proprioception is sloppy, no amount of step 5 strength can save you. The 100 kg bench press is irrelevant if the racket arrives 80 ms late. |
| **The "muscle-bound" paradox:** endurance athletes (runners, cyclists, swimmers) consistently show *faster* reaction times than strength athletes (powerlifters, bodybuilders) of the same age and training age — even though their peak force is lower. The reason: endurance training floods the nervous system with clean, fast proprioceptive feedback (joints cycling thousands of times per session). The powerlifter's nervous system is optimised for *one* high-force output, not for *many* rapid adjustments. Tennis is the second sport, not the first. |
| **What this means at 50+:** nerve conduction velocity drops a few percent per decade. Voluntary reaction time drops more. But SLR and LLR are *just as fast* at 55 as at 25. The "aging" of reflexes is mostly a myth — what ages is the *quality* of the proprioceptive signal, not the speed of the reflex circuit. Train the signal, keep the speed. |
| **🎯 Master Cue / Câu Nhắc Tổng:** *You cannot lift your way to a faster first step. The first step is fired by the spinal cord, not the bicep. Re-train the spinal cord.* / *Anh không thể tập tạ mà có bước đầu nhanh hơn. Bước đầu được kích hoạt bởi tủy sống, không phải bắp tay. Hãy tái huấn luyện tủy sống.* |
| **🧓 50+ Note / Ghi Chú 50+:** A 2025 randomized trial showed that older adults who did 12 weeks of neuromuscular training improved reaction time by 15–25% — more than the control group doing general strength training. The neural circuit is plastic. The age excuse is dead. / *Một thử nghiệm ngẫu nhiên năm 2025 cho thấy người lớn tuổi tập thần kinh-cơ 12 tuần cải thiện thời gian phản ứng 15–25% — nhiều hơn nhóm đối chứng tập sức mạnh tổng quát. Mạch thần kinh dẻo. Cái cớ tuổi tác đã chết.* |

---

## Chapter 4 — The 4-Week Proprioception Reset / Chương Trình Tái Lập 4 Tuần

| 🇺🇸 English |
| --- |
| **Program rules / Quy tắc chương trình:** 3 sessions per week, 30–35 min each. Format: 5 min warm-up (joint rotations, racket swinging without ball) + 20 min proprioception drill + 5–10 min transfer to real hitting. Every session must include at least one drill with **eyes closed** for the last 0.5 seconds before contact. The 0.5-second eye closure is the entire program in miniature — it forces the brain to fall back on proprioception because vision is removed at the decisive moment. / 3 buổi/tuần, 30–35 phút mỗi buổi. Cấu trúc: 5 phút khởi động (xoay khớp, swing vợt không bóng) + 20 phút bài tập cảm thụ bản thể + 5–10 phút chuyển sang đánh thật. Mỗi buổi phải có ít nhất một bài **nhắm mắt** 0.5 giây cuối trước tiếp xúc. 0.5 giây nhắm mắt đó chính là cả chương trình thu nhỏ — nó ép não dựa vào cảm thụ bản thể vì thị giác bị lấy đi ở khoảnh khắc quyết định. |
| **WEEK 1 — Wake up the body map. / TUẦN 1 — Đánh thức bản đồ cơ thể.** **Goal:** the brain re-learns where the racket head is without looking. **Drill A — Choke-up feel (5 min):** grip the racket 2 cm shorter than normal. Stand 1 m from a wall. Tap-bounce the ball against the wall 50 times using only the wrist (shoulder stays still). Focus the entire attention on the *pressure* between index finger and pinky. You are training Input 4 (racket position) at the most sensitive part of the grip. **Drill B — Eyes-closed 8-figure (3 min):** close your eyes, hold the racket in front of you, trace a slow figure-8 in the air. The head should be moving in a continuous loop, wrist articulating smoothly. Open eyes only to check accuracy. **Drill C — Blind slow rally (10 min):** rally with a partner at slow pace. Close your eyes for the last 0.5 s before each contact. Open immediately at contact. You will miss often at first. That is the data. **Drill D — Sweet-spot sound hunt (2 min):** drop-bounce the ball on the strings 20 times. Listen for the **cốc** (sharp, ringing) sound. That is center. Anything else is off. / **Mục tiêu:** não học lại vị trí đầu vợt mà không cần nhìn. **Bài A — Choke-up feel (5 phút):** cầm vợt ngắn hơn 2 cm so với bình thường. Đứng cách tường 1 m. Gõ bóng vào tường 50 lần chỉ dùng cổ tay (vai giữ yên). Tập trung toàn bộ chú ý vào *áp lực* giữa ngón trỏ và ngón út. Anh đang tập Đầu vào 4 (vị trí vợt) ở phần nhạy cảm nhất của grip. **Bài B — Vẽ số 8 nhắm mắt (3 phút):** nhắm mắt, cầm vợt phía trước, vẽ một số 8 chậm trong không khí. Đầu vợt di chuyển thành vòng liên tục, cổ tay linh hoạt mượt. Mở mắt chỉ để kiểm tra độ chính xác. **Bài C — Rally chậm nhắm mắt (10 phút):** rally với bạn tập ở tốc độ chậm. Nhắm mắt 0.5 giây cuối trước mỗi tiếp xúc. Mở ngay lúc tiếp xúc. Anh sẽ trượt nhiều lúc đầu. Đó là dữ liệu. **Bài D — Săn âm sweet spot (2 phút):** thả bóng rơi trên mặt vợt 20 lần. Nghe âm **cốc** (sắc, vang). Đó là tâm. Cái gì khác là lệch. |
| **WEEK 2 — Add noise, keep the structure. / TUẦN 2 — Thêm nhiễu, giữ cấu trúc.** **Goal:** short-latency reflex (20–45 ms) learns to keep the racket stable when surprised. **Drill A — Wobble-board or folded-towel balance (5 min):** stand on a folded towel (or wobble board) holding the racket in ready position. Hold 30 s × 3 sets. Eyes open first week, then eyes closed for 10 s segments. Trains ankle proprioception and the whole lower-chain stability. **Drill B — Leverage switching (7 min):** alternate grips every 10 balls — long grip (serve grip, racket handle fully extended) for 10 balls, then choke-up (dink grip, 2 cm short) for 10 balls, repeat 3 rounds. The brain must re-calculate Input 4 (racket position) every time the leverage changes. **Drill C — On-the-rise contact (5 min):** partner feeds a low-bouncing ball. You must contact the ball on the way *up*, before it peaks. Forces Input 2 (velocity) and Input 1 (joint angle) to fire earlier. The racket must be in position before the ball reaches its peak. **Drill D — Uneven footwork + block (5 min):** stand on a thin yoga mat (folded once). Partner throws balls randomly left or right. You must block (no swing) — Input 1 (joint angle) and Input 4 (racket position) must be automatic. 4 sets × 15 balls. / **Mục tiêu:** phản xạ short-latency (20–45 ms) học giữ vợt ổn định khi bị bất ngờ. **Bài A — Ván bập bênh hoặc khăn gấp (5 phút):** đứng trên khăn gấp (hoặc ván bập bênh) cầm vợt ở vị trí sẵn sàng. Giữ 30 giây × 3 hiệp. Mắt mở tuần đầu, rồi nhắm 10 giây mỗi đoạn. Tập cảm thụ bản thể cổ chân và ổn định toàn chuỗi dưới. **Bài B — Chuyển đòn bẩy (7 phút):** luân phiên grip mỗi 10 bóng — cầm dài (grip serve, cán vợt kéo dài hết) 10 bóng, rồi choke-up (grip dink, ngắn 2 cm) 10 bóng, lặp 3 vòng. Não phải tính lại Đầu vào 4 (vị trí vợt) mỗi lần đòn bẩy đổi. **Bài C — Tiếp xúc on-the-rise (5 phút):** bạn tập feed bóng nảy thấp. Anh phải tiếp xúc bóng khi đang đi *lên*, trước khi bóng đạt đỉnh. Ép Đầu vào 2 (vận tốc) và Đầu vào 1 (góc khớp) phải kích hoạt sớm hơn. Vợt phải ở vị trí trước khi bóng tới đỉnh. **Bài D — Block trên bề mặt không bằng phẳng (5 phút):** đứng trên thảm yoga mỏng (gấp một lần). Bạn tập ném bóng ngẫu nhiên trái hoặc phải. Anh phải block (không swing) — Đầu vào 1 (góc khớp) và Đầu vào 4 (vị trí vợt) phải tự động. 4 hiệp × 15 bóng. |
| **WEEK 3 — Speed of processing, not power. / TUẦN 3 — Tốc độ xử lý, không tăng lực.** **Goal:** long-latency reflex (~60 ms) becomes automatic. **Drill A — Two-point partner drill (10 min):** partner stands 3 m in front. Before each feed, partner points left or right with the racket. You must split-step and block in the pointed direction. 3 sets × 12 balls. The pointing cue is *feedforward* — it gives your brain permission to commit before the ball arrives, training Input 2 (velocity) to fire pre-emptively. **Drill B — Strobe-glasses rally (8 min):** wear strobe glasses (or improvise: close eyes for 200 ms intervals) during slow rallies. The strobe removes continuous visual feedback and forces reliance on Input 4 (racket position) and Input 1 (joint angle). 40 balls. **Drill C — Blind return (5 min):** rally normally, but close your eyes for 70% of the ball's flight time. Open them only in the last 100 ms before contact. The ball becomes a *prediction* instead of a *tracking* exercise. **Drill D — Posterior shoulder protection (5 min):** light resistance band, external rotation of the shoulder, 2 sets × 12 reps, hold 2 s at end range. This is the structural insurance — at 50+ the rotator cuff needs this work or the speed gains from week 1–3 will hurt instead of help. / **Mục tiêu:** phản xạ long-latency (~60 ms) trở nên tự động. **Bài A — Bài tập 2 điểm với bạn tập (10 phút):** bạn tập đứng cách 3 m. Trước mỗi feed, bạn tập chỉ trái hoặc phải bằng vợt. Anh phải split-step và block về hướng được chỉ. 3 hiệp × 12 bóng. Tín hiệu chỉ là *feedforward* — nó cho phép não cam kết trước khi bóng tới, tập Đầu vào 2 (vận tốc) kích hoạt trước. **Bài B — Rally kính nhấp nháy (8 phút):** đeo kính nhấp nháy (hoặc tự chế: nhắm mắt 200 ms mỗi đoạn) trong rally chậm. Kính nhấp nháy lấy đi phản hồi thị giác liên tục và ép dựa vào Đầu vào 4 (vị trí vợt) và Đầu vào 1 (góc khớp). 40 bóng. **Bài C — Trả bóng nhắm mắt (5 phút):** rally bình thường, nhưng nhắm mắt 70% thời gian bay của bóng. Mở mắt chỉ 100 ms cuối trước tiếp xúc. Bóng trở thành *dự đoán* thay vì bài tập *theo dõi*. **Bài D — Bảo vệ vai sau (5 phút):** dây kháng lực nhẹ, xoay ngoài vai, 2 hiệp × 12 lần, giữ 2 giây ở cuối tầm. Đây là bảo hiểm cấu trúc — ở 50+ chóp xoay cần bài này, không thì tăng tốc từ tuần 1–3 sẽ đau thay vì giúp. |
| **WEEK 4 — Bring it into the match. / TUẦN 4 — Đưa vào trận.** **Goal:** proprioception runs in-game, not just in drills. **Drill A — 7-point "block-only" games (15 min):** play real points, but the rule is: compact swing + choke-up only. Lose the point if you take a full swing. Forces the brain to use Input 4 (racket position) at match speed under pressure. **Drill B — Space-switching drill (10 min):** rally dink (ball close, racket short). Without warning, partner lobs deep. You must retreat, switch to long grip, take a full swing. Repeat 20 times. The grip-change must happen *during* the footwork, not after. This is the racket-as-body-schema test. **Drill C — Sensory cooldown (5 min):** hold the racket, close eyes, trace a slow figure-8 in the air for 1 minute. The head should feel like a fingertip — you can "feel" where the strings are pointing without looking. If the head feels like a wooden plank, you need another 4 weeks. / **Mục tiêu:** cảm thụ bản thể chạy trong trận, không còn là bài tập. **Bài A — Trận 7 điểm "chỉ block" (15 phút):** chơi điểm thật, nhưng luật là: compact swing + choke-up. Thua điểm nếu swing đầy. Ép não dùng Đầu vào 4 (vị trí vợt) ở tốc độ trận dưới áp lực. **Bài B — Bài tập chuyển không gian (10 phút):** rally dink (bóng gần, vợt ngắn). Không báo trước, bạn tập lob sâu. Anh phải lùi, đổi sang cầm dài, swing đầy. Lặp 20 lần. Việc đổi grip phải xảy ra *trong lúc* di chuyển chân, không phải sau. Đây là bài kiểm tra vợt-như-lược-đồ-cơ-thể. **Bài C — Hạ nhiệt cảm giác (5 phút):** cầm vợt, nhắm mắt, vẽ số 8 chậm trong không khí 1 phút. Đầu vợt phải cảm thấy như đầu ngón tay — anh có thể "cảm" được mặt vợt đang chĩa đâu mà không cần nhìn. Nếu đầu vợt cảm thấy như tấm ván gỗ, anh cần thêm 4 tuần nữa. |
| **Tracking progress / Theo dõi tiến bộ:** **Metric 1:** subjectively, does the ball "feel slower" by week 4? If yes, your proprioception is now arriving earlier than vision. **Metric 2:** count successful blocks in 20 fast feeds in week 1 vs. week 4. Target: +20–30%. **Metric 3:** does your wrist or shoulder ache the morning after? If yes, you are doing too much volume — cut reps by 30%, not by skipping the drill. **Metric 4:** can you touch your nose with eyes closed (see Chapter 6)? Re-test every Sunday. / **Chỉ số 1:** chủ quan, bóng có "cảm thấy chậm hơn" vào tuần 4 không? Nếu có, cảm thụ bản thể giờ tới sớm hơn thị giác. **Chỉ số 2:** đếm số block thành công trong 20 feed nhanh tuần 1 vs tuần 4. Mục tiêu: +20–30%. **Chỉ số 3:** cổ tay hoặc vai có đau sáng hôm sau không? Nếu có, anh đang tập quá tải — giảm 30% số lần, không bỏ buổi. **Chỉ số 4:** anh có chạm được mũi khi nhắm mắt không (xem Chương 6)? Test lại mỗi Chủ Nhật. |
| **🎯 Master Cue / Câu Nhắc Tổng:** *Four weeks. Twenty minutes a day. Eyes closed for 0.5 seconds before every contact. That's the whole program. Consistency beats intensity.* / *Bốn tuần. Hai mươi phút mỗi ngày. Nhắm mắt 0.5 giây trước mỗi tiếp xúc. Đó là cả chương trình. Nhất quán thắng cường độ.* |
| **🧓 50+ Note / Ghi Chú 50+:** if you have any wrist or shoulder history, start with Week 1 drills only, twice a week, for two weeks before moving to Week 2. The neural gains are real, but the connective tissue needs slower loading. / *Nếu anh có tiền sử cổ tay hoặc vai, hãy bắt đầu chỉ với bài Tuần 1, hai lần một tuần, trong hai tuần trước khi chuyển sang Tuần 2. Lợi ích thần kinh là thật, nhưng mô liên kết cần tải chậm hơn.* |

---

## Chapter 5 — The 50+ Advantage / Lợi Thế 50+

| 🇺🇸 English |
| --- |
| **The asymmetry:** strength declines ~1% per year after 50 (sarcopenia). Nerve conduction velocity declines ~0.5% per year after 50 (mild demyelination). Voluntary reaction time declines ~1–2% per year after 50. But **proprioceptive acuity** — the precision of the position sense — does **not** have a fixed decline curve. It is maintained by use. Use it, keep it. Stop using it, lose it. A 55-year-old who plays tennis 3x/week and adds the 4-week reset has proprioceptive data as clean as a 30-year-old desk worker. |
| **The 2025 evidence:** a randomized controlled trial published in 2025 compared neuromuscular training (the kind in this deep-dive) against general strength training in adults aged 60–75. The neuromuscular group improved reaction time by 18% and proprioceptive accuracy by 24% in 12 weeks. The strength group improved strength by 12% but reaction time by only 3%. Translation: training the *signal* beats training the *output* for reaction time, at any age. |
| **The secret of older elite players:** watch a 50-something league player who is still reaching balls that should be past him. The secret is almost never speed or strength — it is that his racket is in position 30–50 ms earlier than his opponent's, because his proprioceptive system has had decades of refinement. He does not need to see the ball clearly. He can feel the ball arrive on the strings. |
| **The Henry-at-52 protocol:** at our age, the smart play is: **(1)** proprioception 3x/week as the primary training. **(2)** strength 2x/week as the support, not the lead. **(3)** tennis practice 2–3x/week as the transfer test. The order matters. Most club players over 50 invert the order — they hit balls, then lift weights, then wonder why their reaction time is the same as it was five years ago. |
| **The "second wind" of tennis after 50:** many players experience a sudden plateau in their 40s, then a *renewal* in their late 50s — provided they shift from strength-based training to proprioception-based training. The plateau is the moment when the body stops compensating for the brain. The renewal is the moment when the brain starts doing what it should have been doing all along. You are not too old. You are under-trained in the right thing. |
| **🎯 Master Cue / Câu Nhắc Tổng:** *At 50, the race is no longer about who can lift heavier. It's about who can sense sooner. And sensing is the one thing that improves with age when you train it.* / *Ở tuổi 50, cuộc đua không còn là ai tạ nặng hơn. Mà là ai cảm được sớm hơn. Và cảm giác là thứ duy nhất cải thiện theo tuổi khi anh tập nó.* |
| **🧓 50+ Note / Ghi Chú 50+:** don't try to "make up" for lost strength with more proprioception training. Strength and proprioception are different circuits. The protocol is: train proprioception 3x/week, maintain strength 2x/week, do not add volume to either. / *Đừng cố "bù" sức mạnh đã mất bằng cách tập cảm thụ bản thể nhiều hơn. Sức mạnh và cảm thụ bản thể là hai mạch khác nhau. Phác đồ là: tập cảm thụ bản thể 3 lần/tuần, duy trì sức mạnh 2 lần/tuần, đừng tăng khối lượng ở cái nào.* |

---

## Chapter 6 — The Nose-Touch Diagnostic / Chẩn Đoán Chạm Mũi

| 🇺🇸 English |
| --- |
| **The test:** stand in a relaxed stance, arms at sides, eyes closed. Slowly raise one arm and try to touch the tip of your nose with the index finger of that hand. Do it slowly — not fast, not slow, just controlled. Now switch hands. Compare left and right. The distance between where your finger lands and the actual tip of your nose is your **proprioceptive error** in millimetres. |
| **How to score it:** |
| **< 1 cm error:** excellent. Your proprioceptive map is fine-grained. The racket is likely embodied — you can probably feel the sweet spot without looking. Move to advanced proprioception challenges (strobe glasses, two-point partner drill). |
| **1–2 cm error:** normal for most adult recreational players. Awareness is present but coarse. The 4-week reset will likely drop you into the < 1 cm range. Start at Week 1. |
| **2–5 cm error:** significant proprioceptive deficit. Common in players who have not done any hand-eye-coordination work in years, or who have had a shoulder/wrist injury. The 4-week reset is mandatory, twice a week minimum, and consider a sports-physio screen for underlying joint restriction. |
| **> 5 cm error or complete miss:** serious. Do not start the 4-week program yet. Get a neurological screen first — proprioception this poor can indicate cervical spine issues, peripheral neuropathy, or post-injury deafferentation. Tennis is not the priority. A medical workup is. |
| **Test both arms and both sides of the body:** repeat the nose-touch with each hand, then with the foot (try to touch your nose with your big toe — yes, it sounds silly, but it reveals lower-chain proprioception that affects split-step timing). The asymmetry between left and right is often more diagnostic than the absolute error. If the racket arm is significantly worse than the off-hand, you have a unilateral proprioceptive gap that needs targeted work. |
| **Re-test weekly:** the nose-touch is your cheapest, fastest diagnostic. Do it every Sunday before your 4-week reset session. Write the error in millimetres in your phone. By week 4, you should see a 30–50% reduction. If not, increase the volume of Week 1–2 drills before moving to Week 3. |
| **🎯 Master Cue / Câu Nhắc Tổng:** *Test your nose. Test your toe. Test your racket. The error tells you how blind your brain is. Shrink the error, shrink the gap between you and the ball.* / *Test mũi anh. Test ngón chân anh. Test cây vợt anh. Sai số cho biết não anh mù cỡ nào. Thu nhỏ sai số, thu nhỏ khoảng cách giữa anh và bóng.* |
| **🧓 50+ Note / Ghi Chú 50+:** at 50+, a 1.5–2 cm error is normal and not a sign of decline — it is the baseline. The 4-week reset reliably drops 50+ players to < 1 cm if done consistently. Don't compare yourself to a 25-year-old's score; compare yourself to your score from last month. / *Ở 50+, sai số 1.5–2 cm là bình thường và không phải dấu hiệu suy giảm — đó là đường cơ sở. Chương trình 4 tuần đáng tin cậy đưa người chơi 50+ về < 1 cm nếu làm đều. Đừng so với điểm 25 tuổi; hãy so với điểm tháng trước của anh.* |

---

* * *

## The 4-Week Reset Program at a Glance / Chương Trình 4 Tuần Nhìn Nhanh

| Week | Theme | Chủ Đề | Key Drills | Bài Tập Chính | Goal / Mục Tiêu |
|---|---|---|---|---|---|
| 1 | Wake up the body map | Đánh thức bản đồ cơ thể | Choke-up feel, Eyes-closed 8-figure, Blind slow rally, Sweet-spot sound hunt | Choke-up feel, Vẽ số 8 nhắm mắt, Rally chậm nhắm mắt, Săn âm sweet spot | Brain re-learns where the racket is without looking / Não học lại vị trí vợt mà không cần nhìn |
| 2 | Add noise, keep structure | Thêm nhiễu, giữ cấu trúc | Wobble-board, Leverage switching, On-the-rise contact, Uneven footwork + block | Ván bập bênh, Chuyển đòn bẩy, Tiếp xúc on-the-rise, Block trên mặt không bằng phẳng | Short-latency reflex learns to stabilize under surprise / SLR học ổn định khi bất ngờ |
| 3 | Speed of processing | Tốc độ xử lý | Two-point partner drill, Strobe-glasses rally, Blind return, Posterior shoulder | Bài 2 điểm, Rally kính nhấp nháy, Trả bóng nhắm mắt, Bảo vệ vai sau | Long-latency reflex becomes automatic / LLR trở nên tự động |
| 4 | Bring it into the match | Đưa vào trận | 7-point "block-only" games, Space-switching, Sensory cooldown | Trận 7 điểm "chỉ block", Chuyển không gian, Hạ nhiệt cảm giác | Proprioception runs in-game / Cảm thụ bản thể chạy trong trận |

---

* * *

## 🖨️ Printable 1-Page Cheat Sheet / Bảng Câu Nhắc 1 Trang In Ra Được

```
╔══════════════════════════════════════════════════════════════════════════════════════════════════════════╗
║  PROPRIOCEPTION — YOUR HIDDEN GPS  ·  1-PAGE COURT CHEAT SHEET                                           ║
║  CẢM THỤ BẢN THỂ — GPS ẨN CỦA BẠN  ·  BẢNG CÂU NHẮC 1 TRANG                                          ║
╠══════════════════════════════════════════════════════════════════════════════════════════════════════════╣
║                                                                                                          ║
║  🎯 ONE BIG IDEA / Ý TƯỞNG CỐT LÕI:                                                                    ║
║     Proprioception is data. Strength is power. Train the data first.                                     ║
║     Cảm thụ bản thể là dữ liệu. Sức mạnh là công suất. Hãy tập dữ liệu trước.                          ║
║                                                                                                          ║
║  ─────────────────────────────────────────────────────────────────────────────────────────────────────   ║
║  🧠 THE 4 INPUTS / 4 ĐẦU VÀO:                                                                          ║
║     1. Joint Angle   — Góc Khớp       (Ruffini, Pacinian): where each joint is                          ║
║     2. Velocity      — Vận Tốc        (Muscle spindle): how fast each joint is moving                   ║
║     3. Force         — Lực            (Golgi tendon): how hard each muscle is pulling                   ║
║     4. Racket Position — Vị Trí Vợt   (Frame vibration + wrist torque): where the head is               ║
║                                                                                                          ║
║  ─────────────────────────────────────────────────────────────────────────────────────────────────────   ║
║  🔊 THE 4 SOUNDS / 4 ÂM THANH:                                                                          ║
║     cốc  — sharp/ringing   — everything aligned (joint+velocity+force+position ✓)                       ║
║     bộp  — muffled/thud    — position off (sweet spot missed >5cm)                                       ║
║     phập — soft/swish      — force off (angle right, power too low)                                      ║
║     bịch — crisp/dead      — velocity off (firm contact, no swing)                                       ║
║     pực  — heavy/thump     — force + topspin aligned (ball brushing up the string-bed)                   ║
║                                                                                                          ║
║  ─────────────────────────────────────────────────────────────────────────────────────────────────────   ║
║  📅 4-WEEK RESET / TÁI LẬP 4 TUẦN (3×/week, 30–35 min):                                                ║
║     W1: Choke-up feel · Eyes-closed 8-figure · Blind slow rally · Sound hunt (cốc)                      ║
║         Choke-up · Số 8 nhắm mắt · Rally chậm nhắm mắt · Săn âm cốc                                    ║
║     W2: Wobble board 30s×3 · Leverage switch (long↔choke) · On-the-rise · Block on mat                  ║
║         Ván bập bênh · Đổi đòn bẩy · On-the-rise · Block trên thảm                                     ║
║     W3: 2-point partner drill · Strobe glasses 40 balls · Blind return (70% closed) · Band ER            ║
║         Bài 2 điểm · Kính nhấp nháy · Trả bóng nhắm mắt · Dây kháng xoay ngoài                         ║
║     W4: 7-point "block-only" games · Space-switch (dink→lob→full swing) · Sensory cooldown 1 min         ║
║         Trận 7 điểm "chỉ block" · Chuyển không gian · Hạ nhiệt cảm giác                                ║
║                                                                                                          ║
║  ─────────────────────────────────────────────────────────────────────────────────────────────────────   ║
║  👃 NOSE-TOUCH DIAGNOSTIC / CHẨN ĐOÁN CHẠM MŨI:                                                       ║
║     < 1 cm    →  Excellent, advance to strobe / Xuất sắc, chuyển kính nhấp nháy                          ║
║     1–2 cm   →  Normal, start W1 / Bình thường, bắt đầu Tuần 1                                         ║
║     2–5 cm   →  Deficit, W1 twice/wk + physio screen / Thiếu hụt, W1 2 lần/tuần + khám                 ║
║     > 5 cm   →  See a neurologist first / Khám thần kinh trước                                          ║
║                                                                                                          ║
║  ─────────────────────────────────────────────────────────────────────────────────────────────────────   ║
║  🧓 50+ ADVANTAGE / LỢI THẾ 50+:                                                                        ║
║     • Strength ↓ 1%/yr · Proprioception holds with use                                                  ║
║       Sức mạnh ↓ 1%/năm · Cảm thụ bản thể giữ được nếu dùng                                           ║
║     • 12 wk neuromuscular training → +18% reaction time (2025 RCT)                                       ║
║       12 tuần thần kinh-cơ → +18% thời gian phản ứng (RCT 2025)                                         ║
║     • SLR and LLR are just as fast at 55 as at 25 — train the signal                                    ║
║       SLR và LLR nhanh như ở 25 tuổi — hãy tập tín hiệu                                                ║
║                                                                                                          ║
║  ─────────────────────────────────────────────────────────────────────────────────────────────────────   ║
║  💭 MASTER CUE / CÂU NHẮC TỔNG:                                                                         ║
║     "Close your eyes 0.5 seconds before contact. The dark is where the racket learns to see."            ║
║     "Hãy nhắm mắt 0.5 giây trước tiếp xúc. Bóng tối là nơi vợt học cách nhìn."                        ║
║                                                                                                          ║
╚══════════════════════════════════════════════════════════════════════════════════════════════════════════╝
```

```
╔══════════════════════════════════════════════════════════════════════════════════════════════════════════╗
║  PROPRIOCEPTION — YOUR HIDDEN GPS  ·  1-PAGE COURT CHEAT SHEET                                           ║
║  CẢM THỤ BẢN THỂ — GPS ẨN CỦA BẠN  ·  BẢNG CÂU NHẮC 1 TRANG                                          ║
╠══════════════════════════════════════════════════════════════════════════════════════════════════════════╣
║                                                                                                          ║
║  🎯 ONE BIG IDEA / Ý TƯỞNG CỐT LÕI:                                                                    ║
║     Proprioception is data. Strength is power. Train the data first.                                     ║
║     Cảm thụ bản thể là dữ liệu. Sức mạnh là công suất. Hãy tập dữ liệu trước.                          ║
║                                                                                                          ║
║  ─────────────────────────────────────────────────────────────────────────────────────────────────────   ║
║  🧠 THE 4 INPUTS / 4 ĐẦU VÀO:                                                                          ║
║     1. Joint Angle   — Góc Khớp       (Ruffini, Pacinian): where each joint is                          ║
║     2. Velocity      — Vận Tốc        (Muscle spindle): how fast each joint is moving                   ║
║     3. Force         — Lực            (Golgi tendon): how hard each muscle is pulling                   ║
║     4. Racket Position — Vị Trí Vợt   (Frame vibration + wrist torque): where the head is               ║
║                                                                                                          ║
║  ─────────────────────────────────────────────────────────────────────────────────────────────────────   ║
║  🔊 THE 4 SOUNDS / 4 ÂM THANH:                                                                          ║
║     cốc  — sharp/ringing   — everything aligned (joint+velocity+force+position ✓)                       ║
║     bộp  — muffled/thud    — position off (sweet spot missed >5cm)                                       ║
║     phập — soft/swish      — force off (angle right, power too low)                                      ║
║     bịch — crisp/dead      — velocity off (firm contact, no swing)                                       ║
║     pực  — heavy/thump     — force + topspin aligned (ball brushing up the string-bed)                   ║
║                                                                                                          ║
║  ─────────────────────────────────────────────────────────────────────────────────────────────────────   ║
║  📅 4-WEEK RESET / TÁI LẬP 4 TUẦN (3×/week, 30–35 min):                                                ║
║     W1: Choke-up feel · Eyes-closed 8-figure · Blind slow rally · Sound hunt (cốc)                      ║
║         Choke-up · Số 8 nhắm mắt · Rally chậm nhắm mắt · Săn âm cốc                                    ║
║     W2: Wobble board 30s×3 · Leverage switch (long↔choke) · On-the-rise · Block on mat                  ║
║         Ván bập bênh · Đổi đòn bẩy · On-the-rise · Block trên thảm                                     ║
║     W3: 2-point partner drill · Strobe glasses 40 balls · Blind return (70% closed) · Band ER            ║
║         Bài 2 điểm · Kính nhấp nháy · Trả bóng nhắm mắt · Dây kháng xoay ngoài                         ║
║     W4: 7-point "block-only" games · Space-switch (dink→lob→full swing) · Sensory cooldown 1 min         ║
║         Trận 7 điểm "chỉ block" · Chuyển không gian · Hạ nhiệt cảm giác                                ║
║                                                                                                          ║
║  ─────────────────────────────────────────────────────────────────────────────────────────────────────   ║
║  👃 NOSE-TOUCH DIAGNOSTIC / CHẨN ĐOÁN CHẠM MŨI:                                                       ║
║     < 1 cm    →  Excellent, advance to strobe / Xuất sắc, chuyển kính nhấp nháy                          ║
║     1–2 cm   →  Normal, start W1 / Bình thường, bắt đầu Tuần 1                                         ║
║     2–5 cm   →  Deficit, W1 twice/wk + physio screen / Thiếu hụt, W1 2 lần/tuần + khám                 ║
║     > 5 cm   →  See a neurologist first / Khám thần kinh trước                                          ║
║                                                                                                          ║
║  ─────────────────────────────────────────────────────────────────────────────────────────────────────   ║
║  🧓 50+ ADVANTAGE / LỢI THẾ 50+:                                                                        ║
║     • Strength ↓ 1%/yr · Proprioception holds with use                                                  ║
║       Sức mạnh ↓ 1%/năm · Cảm thụ bản thể giữ được nếu dùng                                           ║
║     • 12 wk neuromuscular training → +18% reaction time (2025 RCT)                                       ║
║       12 tuần thần kinh-cơ → +18% thời gian phản ứng (RCT 2025)                                         ║
║     • SLR and LLR are just as fast at 55 as at 25 — train the signal                                    ║
║       SLR và LLR nhanh như ở 25 tuổi — hãy tập tín hiệu                                                ║
║                                                                                                          ║
║  ─────────────────────────────────────────────────────────────────────────────────────────────────────   ║
║  💭 MASTER CUE / CÂU NHẮC TỔNG:                                                                         ║
║     "Close your eyes 0.5 seconds before contact. The dark is where the racket learns to see."            ║
║     "Hãy nhắm mắt 0.5 giây trước tiếp xúc. Bóng tối là nơi vợt học cách nhìn."                        ║
║                                                                                                          ║
╚══════════════════════════════════════════════════════════════════════════════════════════════════════════╝
```

---

*End of Deep Dive. Print the cheat sheet above. Tape it inside your tennis bag. Every session, run the nose-touch test first, then warm up with the Week 1 drills, then play. After four weeks, retest. The number on the diagnostic and the cốc count on your sweet-spot drill are the only two progress metrics that matter. Everything else is noise.*

*Hết bản đi sâu. In bảng câu nhắc phía trên. Dán vào trong túi tennis. Mỗi buổi tập, chạm mũi trước, rồi khởi động bằng bài Tuần 1, rồi chơi. Sau bốn tuần, test lại. Con số trên chẩn đoán và số lần nghe cốc trên bài săn sweet spot là hai chỉ số tiến bộ duy nhất đáng quan tâm. Mọi thứ khác là nhiễu.*
