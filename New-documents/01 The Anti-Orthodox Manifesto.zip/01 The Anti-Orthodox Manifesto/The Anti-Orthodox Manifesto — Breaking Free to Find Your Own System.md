# Deep-Dive #1 — The Anti-Orthodox Manifesto
# Deep-Dive #1 — Tuyên Ngôn Phản Giáo Điều

*Breaking Free to Find Your Own System — A 25-minute deep-dive for the 5.0+ player.*

*Phá Vỡ Để Tìm Hệ Thống Của Riêng Bạn — Deep-dive 25 phút cho người chơi 5.0+.*

---

## 📋 DOCUMENT MAP / BẢN ĐỒ TÀI LIỆU

| 🇺🇸 English |
| --- |
| **What this deep-dive adds.** The Elite Manual Chapter 1 introduced the 5 orthodox lies. This deep-dive takes you through each lie *in your own body*, with a 90-day experiment to test the 5.0+ creed against your lived experience. By the end, you will know which lies you were obeying unconsciously — and you will have replaced each with a personal counter-credential. |
| **Who should read this.** Anyone who has hit a 4.5+ ceiling and suspects the model is wrong. Anyone who has watched a pro highlight reel and felt "I will never do that." Anyone who has been told "you have a fundamental flaw in your forehand" by three coaches and each has prescribed a *different* fundamental flaw. |
| **Reading time.** ~25 minutes. One experiment per lie × 5 lies = 90 days minimum to complete the full creed experiment. |

---

## 📖 TABLE OF CONTENTS / MỤC LỤC

| Chapter | English | Tiếng Việt |
|---|---|---|
| 1 | The Anti-Orthodox Lens | Lăng Kính Phản Giáo Điều |
| 2 | Lie #1 — "Copy the Pros" | Nói Dối #1 — "Bắt Chước Tay Vợt Pro" |
| 3 | Lie #2 — "Perfect Form Exists" | Nói Dối #2 — "Có Hình Thức Hoàn Hảo" |
| 4 | Lie #3 — "10,000 Hours Makes an Expert" | Nói Dối #3 — "10.000 Giờ Tạo Chuyên Gia" |
| 5 | Lie #4 — "The Coach Knows Best" | Nói Dối #4 — "HLV Biết Rõ Nhất" |
| 6 | Lie #5 — "Feel Is the Enemy of Science" | Nói Dối #5 — "Cảm Giác Là Kẻ Thù Của Khoa Học" |
| 7 | The 90-Day Creed Experiment | Thử Nghiệm Tuyên Ngôn 90 Ngày |
| 8 | The Counter-Credential Vault | Kho Chứa Phản-Tín-Chứng |
| 9 | Your Anti-Orthodox Compass | La Bàn Phản Giáo Điều Của Bạn |

* * *

# Chapter 1 — The Anti-Orthodox Lens

* * *

| 🇺🇸 English |
| --- |
| **Why a "lens" and not a "philosophy."** A philosophy is something you argue about. A lens is something you see through. The Anti-Orthodox Lens is a *seeing tool* — once you put it on, you cannot un-see what was always there. You will see orthodoxy everywhere: in coaching articles, in YouTube tutorials, in your own internal voice when you self-correct mid-stroke. |
| **The three things the lens reveals.** |
| **1. Every "rule" was extracted from one body.** When Federer crossed his right leg on the follow-through, coaches wrote a rule: "cross your right leg on the follow-through." Federer's rule came from Federer's body. Your body is not Federer's body. |
| **2. Every "flaw" is a feature of another body.** The "long take-back" that 4.5 coaches love to fix is the same "long take-back" that allows one pro to read the ball an extra 30ms. What is a flaw depends on whose body you're optimizing for. |
| **3. Every "improvement" is a different body in disguise.** When a player "improves" by copying Federer, they have not become Federer. They have become a Federer-shaped version of themselves. That version may or may not be the best version of them. |
| **The lens test.** Pick any piece of tennis advice. Run it through the lens: |
| **(a) Whose body was this extracted from?** |
| **(b) What is the assumption about the player's body that makes this advice apply?** |
| **(c) If that assumption is wrong, is the advice still right?** |
| **If (c) is "no" or "I don't know," you are looking at orthodoxy. Not advice.** |

* * *

# Chapter 2 — Lie #1 — "Copy the Pros"

* * *

| 🇺🇸 English |
| --- |
| **The lie stated fully.** "Watch how Alcaraz hits his forehand. Then hit your forehand the same way." This is the most repeated instruction in all of tennis pedagogy. It is also the most unhelpful for any body that is not Alcaraz's. |
| **Why pros don't copy each other.** This is the part coaches never tell you. Alcaraz does not hit like Nadal. Djokovic does not hit like Federer. Medvedev does not hit like Agassi. The pros *each developed a unique solution that fits their unique body.* They are not copying; they are not "wrong" copies of some Platonic ideal. They are each original. |
| **What "copying" actually produces.** When you try to hit like Alcaraz, your body *attempts* the shape. Your body has different arm length, different shoulder mobility, different hip flexibility, different timing preferences. The result is *a worse version of Alcaraz and a worse version of you.* You lose both. |
| **The personal experiment.** |
| **Step 1.** Pick your favorite pro forehand (the one you most want to copy). Identify ONE specific feature: grip type, take-back height, contact point, finish position. |
| **Step 2.** Spend 1 week trying to copy ONLY that feature. Hit 50 forehands a day. Journal the result. Note: did the feature help, hurt, or stay neutral? |
| **Step 3.** Spend 1 week doing the OPPOSITE. Hit 50 forehands a day, deliberately using the feature's opposite (e.g. take-back short instead of high, contact low instead of high). Journal again. |
| **Step 4.** Spend 1 week doing whatever your body wants. No copying. No opposing. Just notice which version felt best. The answer is your counter-credential. |
| **Total: 21 days per feature tested.** With 5 lies × 5 features each = up to 105 days. The full creed experiment is 90 days minimum. |
| **The expected finding.** Most 5.0+ players, after running this experiment, discover that 2-3 of the "must-copy" features actually hurt them. The pros' features were built for the pros' bodies. Your features are still waiting to be discovered. |

### 📋 Lie #1 Card — Printable / Thẻ In Được Nói Dối #1

    ╔═══════════════════════════════════════════════════════════╗
    ║  LIE #1 CARD — "COPY THE PROS"                             ║
    ║  THẺ NÓI DỐI #1 — "BẮT CHƯỚC TAY VỢT PRO"                ║
    ╠═══════════════════════════════════════════════════════════╣
    ║                                                            ║
    ║  🎯 THE LIE / LỜI NÓI DỐI:                                ║
    ║     "Hit your forehand like Alcaraz."                      ║
    ║     "Đánh forehand anh như Alcaraz."                      ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  WHY IT'S WRONG / TẠI SAO SAI:                             ║
    ║  • Alcaraz's body is not your body.                       ║
    ║    Cơ thể Alcaraz không phải cơ thể bạn.                  ║
    ║  • Pros don't copy each other — they are each original.    ║
    ║    Pro không bắt chước nhau — họ mỗi người nguyên bản.   ║
    ║  • Copying produces a worse Alcaraz and a worse you.       ║
    ║    Bắt chước tạo Alcaraz tệ hơn VÀ bạn tệ hơn.           ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  THE 21-DAY TEST / KIỂM TRA 21 NGÀY:                      ║
    ║  • Week 1: Copy the pro's feature.                         ║
    ║    Tuần 1: Bắt chước đặc điểm pro.                        ║
    ║  • Week 2: Do the opposite.                                ║
    ║    Tuần 2: Làm ngược lại.                                  ║
    ║  • Week 3: Do what your body wants.                        ║
    ║    Tuần 3: Làm điều cơ thể bạn muốn.                      ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  MY COUNTER-CREDENTIAL / PHẢN-TÍN-CHỨNG CỦA TÔI:          ║
    ║     "I tried copying Alcaraz for 21 days. The result       ║
    ║      for MY body was __________________."                  ║
    ║     "Tôi đã thử bắt chước Alcaraz 21 ngày. Kết quả        ║
    ║      cho cơ thể TÔI là __________________."               ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  💭 THE TRUTH / SỰ THẬT:                                  ║
    ║     "Alcaraz is the only Alcaraz. I am the first me."     ║
    ║     "Alcaraz chỉ có một Alcaraz. Tôi là tôi đầu tiên."   ║
    ║                                                            ║
    ╚═══════════════════════════════════════════════════════════╝


    ╔═══════════════════════════════════════════════════════════╗
    ║  LIE #1 CARD — "COPY THE PROS"                             ║
    ║  THẺ NÓI DỐI #1 — "BẮT CHƯỚC TAY VỢT PRO"                ║
    ╠═══════════════════════════════════════════════════════════╣
    ║                                                            ║
    ║  🎯 THE LIE / LỜI NÓI DỐI:                                ║
    ║     "Hit your forehand like Alcaraz."                      ║
    ║     "Đánh forehand anh như Alcaraz."                      ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  WHY IT'S WRONG / TẠI SAO SAI:                             ║
    ║  • Alcaraz's body is not your body.                       ║
    ║    Cơ thể Alcaraz không phải cơ thể bạn.                  ║
    ║  • Pros don't copy each other — they are each original.    ║
    ║    Pro không bắt chước nhau — họ mỗi người nguyên bản.   ║
    ║  • Copying produces a worse Alcaraz and a worse you.       ║
    ║    Bắt chước tạo Alcaraz tệ hơn VÀ bạn tệ hơn.           ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  THE 21-DAY TEST / KIỂM TRA 21 NGÀY:                      ║
    ║  • Week 1: Copy the pro's feature.                         ║
    ║    Tuần 1: Bắt chước đặc điểm pro.                        ║
    ║  • Week 2: Do the opposite.                                ║
    ║    Tuần 2: Làm ngược lại.                                  ║
    ║  • Week 3: Do what your body wants.                        ║
    ║    Tuần 3: Làm điều cơ thể bạn muốn.                      ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  MY COUNTER-CREDENTIAL / PHẢN-TÍN-CHỨNG CỦA TÔI:          ║
    ║     "I tried copying Alcaraz for 21 days. The result       ║
    ║      for MY body was __________________."                  ║
    ║     "Tôi đã thử bắt chước Alcaraz 21 ngày. Kết quả        ║
    ║      cho cơ thể TÔI là __________________."               ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  💭 THE TRUTH / SỰ THẬT:                                  ║
    ║     "Alcaraz is the only Alcaraz. I am the first me."     ║
    ║     "Alcaraz chỉ có một Alcaraz. Tôi là tôi đầu tiên."   ║
    ║                                                            ║
    ╚═══════════════════════════════════════════════════════════╝

* * *

# Chapter 3 — Lie #2 — "Perfect Form Exists"

* * *

| 🇺🇸 English |
| --- |
| **The lie stated fully.** "There is an ideal forehand. Your job is to match it." This is the oldest and most persistent lie in tennis. It has spawned thousands of hours of YouTube analysis, every "fundamental flaw" correction video, every "perfect swing" infographic. It is also — at 5.0+ — the lie most worth demolishing. |
| **The philosophical demolition.** The "ideal forehand" is Platonic. It exists in some abstract space above the court, hovering, waiting for bodies to match it. The problem: there is no such space. There are only bodies. And bodies — yours, Federer's, Nadal's, Alcaraz's, the 3.0 at the public court — are all *different.* The ideal is a fiction created by people who want to teach without meeting you. |
| **The biomechanical demolition.** The human body has approximately 244 degrees of freedom (per Bernstein's classic analysis). A forehand uses maybe 12 of those. That leaves 232 degrees of freedom *unused* in any forehand. Different bodies *use* different unused degrees. This is not error; this is what functional solution looks like in a system with massive redundancy. |
| **The pros themselves.** Watch 5 different pros hit a forehand in slow motion. Count what is *the same:* maybe 3 things (chest turns, racket meets ball, ball goes over net). Count what is *different:* 25+ things (grip, stance, take-back, contact height, finish, body rotation, follow-through, breathing). The pros are not matching an ideal. They are each doing their own version of the 3 things that matter. |
| **The personal experiment — the "5 pros" study.** |
| **Step 1.** Pick 5 different pro forehands (e.g., Alcaraz, Federer, Djokovic, Medvedev, Sabalenka). Watch each at 0.25x speed. |
| **Step 2.** For each, list 3 features that are *the same across all 5* and 3 features that are *wildly different across all 5.* |
| **Step 3.** The 3-same list is your *functional essentials* — the parts of a forehand that actually matter. The 3-different list is your *style variables* — the parts that are purely body-choice. |
| **Step 4.** For 2 weeks, hit forehands while telling yourself only the *functional essentials.* Ignore the style variables entirely. Let your body pick its own. Notice what emerges. |
| **The expected finding.** Most players discover that the "perfect form" they were chasing was mostly style variables disguised as essentials. Once they let go of the style, their functional forehand *improve* within 2 weeks — not because they learned anything new, but because they stopped interfering. |

### 📋 Lie #2 Card — Printable / Thẻ In Được Nói Dối #2

    ╔═══════════════════════════════════════════════════════════╗
    ║  LIE #2 CARD — "PERFECT FORM EXISTS"                       ║
    ║  THẺ NÓI DỐI #2 — "CÓ HÌNH THỨC HOÀN HẢO"                ║
    ╠═══════════════════════════════════════════════════════════╣
    ║                                                            ║
    ║  🎯 THE LIE / LỜI NÓI DỐI:                                ║
    ║     "There is an ideal forehand. Match it."                ║
    ║     "Có một cú forehand lý tưởng. Khớp nó."                ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  WHY IT'S WRONG / TẠI SAO SAI:                             ║
    ║  • No ideal exists. Only bodies.                           ║
    ║    Không có lý tưởng. Chỉ có cơ thể.                      ║
    ║  • The body has 244 degrees of freedom.                    ║
    ║    Cơ thể có 244 bậc tự do.                                ║
    ║  • Pros do 3 things the same; 25 things differently.       ║
    ║    Pro làm 3 thứ giống; 25 thứ khác nhau.                  ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  THE "5 PROS" STUDY / NGHIÊN CỨU "5 PRO":                 ║
    ║  • Watch 5 different pro forehands at 0.25x.              ║
    ║    Xem 5 forehand pro khác nhau ở 0.25x.                  ║
    ║  • List 3 things same. List 3 things different.            ║
    ║    Liệt kê 3 thứ giống. Liệt kê 3 thứ khác.              ║
    ║  • The "same" list is your essentials.                    ║
    ║    Danh sách "giống" là yếu tố cốt lõi.                  ║
    ║  • The "different" list is style — yours to choose.       ║
    ║    Danh sách "khác" là phong cách — của bạn chọn.        ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  MY FUNCTIONAL ESSENTIALS / YẾU TỐ CỐT LÕI CỦA TÔI:      ║
    ║  1. ____________________________________                   ║
    ║  2. ____________________________________                   ║
    ║  3. ____________________________________                   ║
    ║                                                            ║
    ║  MY STYLE CHOICES / LỰA CHỌN PHONG CÁCH CỦA TÔI:          ║
    ║  1. ____________________________________                   ║
    ║  2. ____________________________________                   ║
    ║  3. ____________________________________                   ║
    ║                                                            ║
    ║  💭 THE TRUTH / SỰ THẬT:                                  ║
    ║     "Functional essentials are universal. Style is yours." ║
    ║     "Yếu tố cốt lõi chức năng là phổ quát. Phong cách   ║
    ║      là của bạn."                                           ║
    ║                                                            ║
    ╚═══════════════════════════════════════════════════════════╝


    ╔═══════════════════════════════════════════════════════════╗
    ║  LIE #2 CARD — "PERFECT FORM EXISTS"                       ║
    ║  THẺ NÓI DỐI #2 — "CÓ HÌNH THỨC HOÀN HẢO"                ║
    ╠═══════════════════════════════════════════════════════════╣
    ║                                                            ║
    ║  🎯 THE LIE / LỜI NÓI DỐI:                                ║
    ║     "There is an ideal forehand. Match it."                ║
    ║     "Có một cú forehand lý tưởng. Khớp nó."                ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  WHY IT'S WRONG / TẠI SAO SAI:                             ║
    ║  • No ideal exists. Only bodies.                           ║
    ║    Không có lý tưởng. Chỉ có cơ thể.                      ║
    ║  • The body has 244 degrees of freedom.                    ║
    ║    Cơ thể có 244 bậc tự do.                                ║
    ║  • Pros do 3 things the same; 25 things differently.       ║
    ║    Pro làm 3 thứ giống; 25 thứ khác nhau.                  ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  THE "5 PROS" STUDY / NGHIÊN CỨU "5 PRO":                 ║
    ║  • Watch 5 different pro forehands at 0.25x.              ║
    ║    Xem 5 forehand pro khác nhau ở 0.25x.                  ║
    ║  • List 3 things same. List 3 things different.            ║
    ║    Liệt kê 3 thứ giống. Liệt kê 3 thứ khác.              ║
    ║  • The "same" list is your essentials.                    ║
    ║    Danh sách "giống" là yếu tố cốt lõi.                  ║
    ║  • The "different" list is style — yours to choose.       ║
    ║    Danh sách "khác" là phong cách — của bạn chọn.        ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  MY FUNCTIONAL ESSENTIALS / YẾU TỐ CỐT LÕI CỦA TÔI:      ║
    ║  1. ____________________________________                   ║
    ║  2. ____________________________________                   ║
    ║  3. ____________________________________                   ║
    ║                                                            ║
    ║  MY STYLE CHOICES / LỰA CHỌN PHONG CÁCH CỦA TÔI:          ║
    ║  1. ____________________________________                   ║
    ║  2. ____________________________________                   ║
    ║  3. ____________________________________                   ║
    ║                                                            ║
    ║  💭 THE TRUTH / SỰ THẬT:                                  ║
    ║     "Functional essentials are universal. Style is yours." ║
    ║     "Yếu tố cốt lõi chức năng là phổ quát. Phong cách   ║
    ║      là của bạn."                                           ║
    ║                                                            ║
    ╚═══════════════════════════════════════════════════════════╝

* * *

# Chapter 4 — Lie #3 — "10,000 Hours Makes an Expert"

* * *

| 🇺🇸 English |
| --- |
| **The lie stated fully.** "Practice 10,000 hours and you will become an expert." This is the Ericsson "deliberate practice" rule, popularized by Gladwell, repeated by every tennis parent, internalized by every player who has spent 5,000 hours and wonders why they are still 4.0. |
| **What Ericsson actually said.** Anders Ericsson, the researcher behind the 10,000-hour rule, was careful about *one thing:* the hours must be *deliberate* — specific, effortful, with feedback. *Deliberate* practice. Not *any* practice. *Specific* practice. Not *repetitive* practice. The popular version dropped the adjectives. The popular version is wrong. |
| **The hidden variable.** The 10,000-hour rule hides a critical variable: *what* is being practiced. If the hours are spent grooving a flawed forehand, the player has not built skill. The player has built *faster, more automatic error.* This is the cruel joke of practice: myelin doesn't judge. It insulates whatever pathway is fired repeatedly. |
| **The math the popular version forgets.** A typical 4.0 player hits maybe 1,500 forehands per month of regular play. That's 18,000 forehands a year. After 5 years, 90,000 forehands. *Yet the forehand is still 4.0.* The hours are not the bottleneck. The hours were practice, but not *deliberate* practice — there was no specific feedback loop, no progressive challenge, no attention to detail. There was just repetition. |
| **The "deliberate" test.** A quick way to check if your hours are deliberate: ask, "What was I trying to learn in that session?" If you have a specific answer ("I was trying to keep my wrist firm at contact"), the hours were deliberate. If the answer is "I was hitting balls," they were not. |
| **The personal experiment — the "100 hours audit."** |
| **Step 1.** Estimate how many hours of tennis you have practiced in the last year. Be honest. |
| **Step 2.** Of those hours, what percentage had a *specific* learning goal (e.g. "increase topspin," "keep head still," "add slice variation")? |
| **Step 3.** Of those hours, what percentage had *feedback* (video review, coach correction, journal reflection, partner observation)? |
| **Step 4.** The hours with both a specific goal AND feedback are your *real* practice hours. The hours without are *filler.* The math: if you practiced 300 hours last year but only 50 were deliberate, you are a 50-hour player, not a 300-hour player. |
| **The recalibration.** Most 5.0+ players, after this audit, find that their "deliberate hours" are 10-20% of their "total hours." This is not a number to be ashamed of. It is a number to be *doubled.* Because doubling deliberate hours — without changing total hours — is the cheapest, fastest way to improve. |

### 📋 Lie #3 Card — Printable / Thẻ In Được Nói Dối #3

    ╔═══════════════════════════════════════════════════════════╗
    ║  LIE #3 CARD — "10,000 HOURS MAKES AN EXPERT"              ║
    ║  THẺ NÓI DỐI #3 — "10.000 GIỜ TẠO CHUYÊN GIA"             ║
    ╠═══════════════════════════════════════════════════════════╣
    ║                                                            ║
    ║  🎯 THE LIE / LỜI NÓI DỐI:                                ║
    ║     "Just put in 10,000 hours."                            ║
    ║     "Cứ bỏ vào 10.000 giờ."                                ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  THE MISSING ADJECTIVES / TÍNH TỪ BỊ THIẾU:              ║
    ║  • 10,000 hours of DELIBERATE practice.                    ║
    ║    10.000 giờ tập CÓ CHỦ ĐÍCH.                           ║
    ║  • Specific, effortful, with feedback.                     ║
    ║    Cụ thể, nỗ lực, có phản hồi.                          ║
    ║  • Repetition is not the same.                             ║
    ║    Lặp lại không giống vậy.                                ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  THE "100 HOURS AUDIT" / "KIỂM TOÁN 100 GIỜ":              ║
    ║  • Total hours last year: ___________                     ║
    ║    Tổng giờ năm ngoái: ___________                        ║
    ║  • With specific goal: ____%  (e.g. 30%)                  ║
    ║    Có mục tiêu cụ thể: ____%  (vd. 30%)                  ║
    ║  • With feedback: ____%  (e.g. 20%)                       ║
    ║    Có phản hồi: ____%  (vd. 20%)                         ║
    ║  • Both (deliberate): ____% × ____% = ____ hrs            ║
    ║    Cả hai (có chủ đích): ____% × ____% = ____ giờ         ║
    ║  • My REAL practice hours = ___________                   ║
    ║    Giờ tập THỰC của tôi = ___________                     ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  💭 THE TRUTH / SỰ THẬT:                                  ║
    ║     "I am a ___ hour player, not a ___ hour player."       ║
    ║     "Tôi là người chơi ___ giờ, không phải ___ giờ."     ║
    ║                                                            ║
    ║     "Myelin doesn't judge. Insulate the right pathways."   ║
    ║     "Myelin không phán xét. Cách điện đúng đường dẫn."   ║
    ║                                                            ║
    ╚═══════════════════════════════════════════════════════════╝


    ╔═══════════════════════════════════════════════════════════╗
    ║  LIE #3 CARD — "10,000 HOURS MAKES AN EXPERT"              ║
    ║  THẺ NÓI DỐI #3 — "10.000 GIỜ TẠO CHUYÊN GIA"             ║
    ╠═══════════════════════════════════════════════════════════╣
    ║                                                            ║
    ║  🎯 THE LIE / LỜI NÓI DỐI:                                ║
    ║     "Just put in 10,000 hours."                            ║
    ║     "Cứ bỏ vào 10.000 giờ."                                ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  THE MISSING ADJECTIVES / TÍNH TỪ BỊ THIẾU:              ║
    ║  • 10,000 hours of DELIBERATE practice.                    ║
    ║    10.000 giờ tập CÓ CHỦ ĐÍCH.                           ║
    ║  • Specific, effortful, with feedback.                     ║
    ║    Cụ thể, nỗ lực, có phản hồi.                          ║
    ║  • Repetition is not the same.                             ║
    ║    Lặp lại không giống vậy.                                ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  THE "100 HOURS AUDIT" / "KIỂM TOÁN 100 GIỜ":              ║
    ║  • Total hours last year: ___________                     ║
    ║    Tổng giờ năm ngoái: ___________                        ║
    ║  • With specific goal: ____%  (e.g. 30%)                  ║
    ║    Có mục tiêu cụ thể: ____%  (vd. 30%)                  ║
    ║  • With feedback: ____%  (e.g. 20%)                       ║
    ║    Có phản hồi: ____%  (vd. 20%)                         ║
    ║  • Both (deliberate): ____% × ____% = ____ hrs            ║
    ║    Cả hai (có chủ đích): ____% × ____% = ____ giờ         ║
    ║  • My REAL practice hours = ___________                   ║
    ║    Giờ tập THỰC của tôi = ___________                     ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  💭 THE TRUTH / SỰ THẬT:                                  ║
    ║     "I am a ___ hour player, not a ___ hour player."       ║
    ║     "Tôi là người chơi ___ giờ, không phải ___ giờ."     ║
    ║                                                            ║
    ║     "Myelin doesn't judge. Insulate the right pathways."   ║
    ║     "Myelin không phán xét. Cách điện đúng đường dẫn."   ║
    ║                                                            ║
    ╚═══════════════════════════════════════════════════════════╝

* * *

# Chapter 5 — Lie #4 — "The Coach Knows Best"

* * *

| 🇺🇸 English |
| --- |
| **The lie stated fully.** "Coach X is an expert. Coach X has seen thousands of players. Coach X knows what is right for you." This is the respect-and-defer lie. It is true at 3.0 (you need fundamentals). It is partly true at 4.0 (you need polish). At 5.0+, it becomes a *trap.* |
| **The trap in three steps.** Step 1: a coach tells you "your take-back is too short." Step 2: you spend 200 hours lengthening it. Step 3: you plateau at a level that is not yours. *The coach may be right about the average player. The coach may be wrong about you.* |
| **What coaches actually know.** Coaches know the *average body.* They have built a mental library of "what works for most bodies." This is enormously valuable for the 3.0 player who has not yet developed a body sense. But for the 5.0+ player — who HAS developed a body sense — the coach's library can become a *filter that blocks what is uniquely yours.* |
| **The hierarchy of coach-value by level.** |
| **3.0 — Coach is essential.** The player has no body sense yet. They need the coach's external model to bootstrap. *Coaching ratio:* 100% coach, 0% player. |
| **4.0 — Coach is helpful.** The player has emerging body sense but inconsistent. The coach provides corrections when the player drifts. *Coaching ratio:* 60% coach, 40% player. |
| **5.0 — Coach is occasional consultant.** The player has a strong body sense. The coach provides *external perspective* the player cannot see themselves. *Coaching ratio:* 30% coach, 70% player. |
| **5.0+ — Coach is one data point among many.** The player *is the coach.* External coaches provide data the player integrates into their own system. *Coaching ratio:* 10% external coach, 90% self-coach. |
| **The "external perspective" experiment.** A 5.0+ player should engage a coach *not* for instruction, but for one specific service: pointing out things the player cannot see from inside. The coach becomes a mirror, not a manual. |
| **The personal experiment — the "5 coaches" study.** |
| **Step 1.** Over the next 6 months, have 1 lesson with 5 different coaches (or 5 different sessions with the same coach over 6 months, each focused on a different stroke). |
| **Step 2.** For each, write down the ONE thing they say is most important about your game. |
| **Step 3.** Compare the 5 things. If they converge ("your backswing is too short" × 5), the coaches may be right. If they diverge ("backswing too short" / "backswing too long" / "weight transfer wrong" / "follow-through off" / "wrist too loose"), they are not diagnosing you — they are each applying their own mental model. The divergence is the data. |
| **The expected finding.** Most 5.0+ players find significant divergence among coach diagnoses. This is not a sign of bad coaching. It is a sign that the coaches' models are about *average bodies,* not about yours. |

### 📋 Lie #4 Card — Printable / Thẻ In Được Nói Dối #4

    ╔═══════════════════════════════════════════════════════════╗
    ║  LIE #4 CARD — "THE COACH KNOWS BEST"                      ║
    ║  THẺ NÓI DỐI #4 — "HLV BIẾT RÕ NHẤT"                     ║
    ╠═══════════════════════════════════════════════════════════╣
    ║                                                            ║
    ║  🎯 THE LIE / LỜI NÓI DỐI:                                ║
    ║     "Coach X has seen thousands of players. Trust them."  ║
    ║     "HLV X đã thấy hàng nghìn người. Tin họ."             ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  THE TRAP / CÁI BẪY:                                       ║
    ║  • Coach diagnoses AVERAGE bodies, not yours.              ║
    ║    HLV chẩn đoán cơ thể TRUNG BÌNH, không của bạn.      ║
    ║  • At 5.0+, their model can become a filter.              ║
    ║    Ở 5.0+, mô hình họ có thể thành bộ lọc.               ║
    ║  • 200 hours fixing "wrong" thing = plateau.               ║
    ║    200 giờ sửa thứ "sai" = bình nguyên.                  ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  THE COACH-VALUE HIERARCHY / HỆ PHÂN CẤP HLV:            ║
    ║  • 3.0 → Coach: 100% (essential)                           ║
    ║    3.0 → HLV: 100% (thiết yếu)                            ║
    ║  • 4.0 → Coach: 60% / Player: 40%                         ║
    ║    4.0 → HLV: 60% / Người chơi: 40%                       ║
    ║  • 5.0 → Coach: 30% / Player: 70%                         ║
    ║    5.0 → HLV: 30% / Người chơi: 70%                       ║
    ║  • 5.0+ → External: 10% / Self-coach: 90%                  ║
    ║    5.0+ → Bên ngoài: 10% / Tự HLV: 90%                   ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  THE "5 COACHES" STUDY / NGHIÊN CỨU "5 HLV":              ║
    ║  Coach 1 says: _____________________________________      ║
    ║  Coach 2 says: _____________________________________      ║
    ║  Coach 3 says: _____________________________________      ║
    ║  Coach 4 says: _____________________________________      ║
    ║  Coach 5 says: _____________________________________      ║
    ║                                                            ║
    ║  Convergence (all same)?  YES / NO                         ║
    ║  Divergence (all different)?  YES / NO                     ║
    ║  If divergence: the coaches model AVERAGES, not you.      ║
    ║  Nếu phân kỳ: mô hình HLV là TRUNG BÌNH, không phải bạn. ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  💭 THE TRUTH / SỰ THẬT:                                  ║
    ║     "The 5.0+ player doesn't need a manual.                ║
    ║      They need a mirror."                                  ║
    ║     "Người chơi 5.0+ không cần sổ tay.                     ║
    ║      Họ cần một tấm gương."                                ║
    ║                                                            ║
    ╚═══════════════════════════════════════════════════════════╝


    ╔═══════════════════════════════════════════════════════════╗
    ║  LIE #4 CARD — "THE COACH KNOWS BEST"                      ║
    ║  THẺ NÓI DỐI #4 — "HLV BIẾT RÕ NHẤT"                     ║
    ╠═══════════════════════════════════════════════════════════╣
    ║                                                            ║
    ║  🎯 THE LIE / LỜI NÓI DỐI:                                ║
    ║     "Coach X has seen thousands of players. Trust them."  ║
    ║     "HLV X đã thấy hàng nghìn người. Tin họ."             ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  THE TRAP / CÁI BẪY:                                       ║
    ║  • Coach diagnoses AVERAGE bodies, not yours.              ║
    ║    HLV chẩn đoán cơ thể TRUNG BÌNH, không của bạn.      ║
    ║  • At 5.0+, their model can become a filter.              ║
    ║    Ở 5.0+, mô hình họ có thể thành bộ lọc.               ║
    ║  • 200 hours fixing "wrong" thing = plateau.               ║
    ║    200 giờ sửa thứ "sai" = bình nguyên.                  ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  THE COACH-VALUE HIERARCHY / HỆ PHÂN CẤP HLV:            ║
    ║  • 3.0 → Coach: 100% (essential)                           ║
    ║    3.0 → HLV: 100% (thiết yếu)                            ║
    ║  • 4.0 → Coach: 60% / Player: 40%                         ║
    ║    4.0 → HLV: 60% / Người chơi: 40%                       ║
    ║  • 5.0 → Coach: 30% / Player: 70%                         ║
    ║    5.0 → HLV: 30% / Người chơi: 70%                       ║
    ║  • 5.0+ → External: 10% / Self-coach: 90%                  ║
    ║    5.0+ → Bên ngoài: 10% / Tự HLV: 90%                   ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  THE "5 COACHES" STUDY / NGHIÊN CỨU "5 HLV":              ║
    ║  Coach 1 says: _____________________________________      ║
    ║  Coach 2 says: _____________________________________      ║
    ║  Coach 3 says: _____________________________________      ║
    ║  Coach 4 says: _____________________________________      ║
    ║  Coach 5 says: _____________________________________      ║
    ║                                                            ║
    ║  Convergence (all same)?  YES / NO                         ║
    ║  Divergence (all different)?  YES / NO                     ║
    ║  If divergence: the coaches model AVERAGES, not you.      ║
    ║  Nếu phân kỳ: mô hình HLV là TRUNG BÌNH, không phải bạn. ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  💭 THE TRUTH / SỰ THẬT:                                  ║
    ║     "The 5.0+ player doesn't need a manual.                ║
    ║      They need a mirror."                                  ║
    ║     "Người chơi 5.0+ không cần sổ tay.                     ║
    ║      Họ cần một tấm gương."                                ║
    ║                                                            ║
    ╚═══════════════════════════════════════════════════════════╝

* * *

# Chapter 6 — Lie #5 — "Feel Is the Enemy of Science"

* * *

| 🇺🇸 English |
| --- |
| **The lie stated fully.** "You can't trust your feel. You need data: HRV, RPM, swing speed, biomechanical models." This is the modern lie — the data lie. It is technically true that data is objective. It is also technically true that the data is *about your past.* Your feel is about your present. |
| **What "data" actually captures.** A biomechanical model is a snapshot. A high-speed camera captures one stroke in 240 frames. Your HRV this morning is one reading. Your RPM from yesterday's session is one number. All of these are *post-hoc measurements* — they describe what already happened, not what is happening *right now* on this shot. |
| **What "feel" actually is.** Feel is the integration of all your sensory data in real time — proprioception, vestibular sense, tactile feedback from the racket, auditory feedback from the contact, visual feedback from the ball flight. It is not vague mysticism. It is *real-time multi-modal data processing* done by a nervous system that has been trained on 1,000s of hours of your body's specific movements. |
| **The data/feel partnership.** The mistake is not choosing one or the other. The mistake is letting either dominate. *Data informs; feel decides.* Data tells you "your forehand was 5° off in take-back angle." Feel tells you "this forehand is right." When data and feel disagree, *feel is more reliable in real time, data is more reliable across time.* |
| **The user's note in the Elite Manual.** *"By 5.0+, feel is the only science you can trust in real time. The numbers describe your past. The feel tells you about this shot."* This is not anti-science. It is *pro-science applied correctly:* real-time data processing is what your nervous system does for free. |
| **The personal experiment — the "blindfold feel test."** |
| **Step 1.** Have a partner feed you 10 forehands. Hit them normally. Rate each "1-10" for "did this feel right?" |
| **Step 2.** Compare your feel-ratings to the actual outcomes (in / out, deep / short). Plot the correlation. |
| **Step 3.** A 5.0+ player's feel should correlate with outcomes at r > 0.6. If yours does, your feel is reliable data. If it does not, your feel needs calibration (more video review + reflection). |
| **Step 4.** Once feel is calibrated, the next time your coach says "your racket angle was 5° off," you can either trust the data OR your feel — and you have a tested way to know which to trust. |

### 📋 Lie #5 Card — Printable / Thẻ In Được Nói Dối #5

    ╔═══════════════════════════════════════════════════════════╗
    ║  LIE #5 CARD — "FEEL IS THE ENEMY OF SCIENCE"              ║
    ║  THẺ NÓI DỐI #5 — "CẢM GIÁC LÀ KẺ THÙ CỦA KHOA HỌC"    ║
    ╠═══════════════════════════════════════════════════════════╣
    ║                                                            ║
    ║  🎯 THE LIE / LỜI NÓI DỐI:                                ║
    ║     "You can't trust feel. Trust the data."                ║
    ║     "Anh không thể tin cảm giác. Tin dữ liệu."            ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  THE PARTNERSHIP / QUAN HỆ ĐỐI TÁC:                       ║
    ║  • Data is post-hoc. Feel is real-time.                    ║
    ║    Dữ liệu là hậu định. Cảm giác là thời gian thực.     ║
    ║  • Data informs. Feel decides.                             ║
    ║    Dữ liệu thông tin. Cảm giác quyết định.                ║
    ║  • When they disagree:                                     ║
    ║    Khi chúng bất đồng:                                    ║
    ║    – Real time → trust feel                               ║
    ║      Thời gian thực → tin cảm giác                       ║
    ║    – Across time → trust data                             ║
    ║      Xuyên thời gian → tin dữ liệu                       ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  THE BLINDFOLD FEEL TEST / KIỂM TRA BỊT MẮT:             ║
    ║  • 10 forehands. Rate each "1-10" for feel.               ║
    ║    10 forehand. Chấm mỗi cái "1-10" cho cảm giác.       ║
    ║  • Compare to outcomes (in/out, deep/short).               ║
    ║    So với kết quả (vào/ra, sâu/ngắn).                    ║
    ║  • Correlation r > 0.6 = feel is reliable data.             ║
    ║    Tương quan r > 0.6 = cảm giác là dữ liệu đáng tin.   ║
    ║  • r < 0.6 = feel needs calibration (more video).          ║
    ║    r < 0.6 = cảm giác cần hiệu chỉnh (thêm video).      ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  MY FEEL-OUTCOME CORRELATION / TƯƠNG QUAN CỦA TÔI:       ║
    ║  Last test date: __________________                        ║
    ║  Rating: ____  (r = ____)                                  ║
    ║                                                            ║
    ║  💭 THE TRUTH / SỰ THẬT:                                  ║
    ║     "Data describes my past. Feel knows my present."       ║
    ║     "Dữ liệu mô tả quá khứ. Cảm giác biết hiện tại."    ║
    ║                                                            ║
    ╚═══════════════════════════════════════════════════════════╝


    ╔═══════════════════════════════════════════════════════════╗
    ║  LIE #5 CARD — "FEEL IS THE ENEMY OF SCIENCE"              ║
    ║  THẺ NÓI DỐI #5 — "CẢM GIÁC LÀ KẺ THÙ CỦA KHOA HỌC"    ║
    ╠═══════════════════════════════════════════════════════════╣
    ║                                                            ║
    ║  🎯 THE LIE / LỜI NÓI DỐI:                                ║
    ║     "You can't trust feel. Trust the data."                ║
    ║     "Anh không thể tin cảm giác. Tin dữ liệu."            ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  THE PARTNERSHIP / QUAN HỆ ĐỐI TÁC:                       ║
    ║  • Data is post-hoc. Feel is real-time.                    ║
    ║    Dữ liệu là hậu định. Cảm giác là thời gian thực.     ║
    ║  • Data informs. Feel decides.                             ║
    ║    Dữ liệu thông tin. Cảm giác quyết định.                ║
    ║  • When they disagree:                                     ║
    ║    Khi chúng bất đồng:                                    ║
    ║    – Real time → trust feel                               ║
    ║      Thời gian thực → tin cảm giác                       ║
    ║    – Across time → trust data                             ║
    ║      Xuyên thời gian → tin dữ liệu                       ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  THE BLINDFOLD FEEL TEST / KIỂM TRA BỊT MẮT:             ║
    ║  • 10 forehands. Rate each "1-10" for feel.               ║
    ║    10 forehand. Chấm mỗi cái "1-10" cho cảm giác.       ║
    ║  • Compare to outcomes (in/out, deep/short).               ║
    ║    So với kết quả (vào/ra, sâu/ngắn).                    ║
    ║  • Correlation r > 0.6 = feel is reliable data.             ║
    ║    Tương quan r > 0.6 = cảm giác là dữ liệu đáng tin.   ║
    ║  • r < 0.6 = feel needs calibration (more video).          ║
    ║    r < 0.6 = cảm giác cần hiệu chỉnh (thêm video).      ║
    ║                                                            ║
    ║  ────────────────────────────────────────────────────────  ║
    ║  MY FEEL-OUTCOME CORRELATION / TƯƠNG QUAN CỦA TÔI:       ║
    ║  Last test date: __________________                        ║
    ║  Rating: ____  (r = ____)                                  ║
    ║                                                            ║
    ║  💭 THE TRUTH / SỰ THẬT:                                  ║
    ║     "Data describes my past. Feel knows my present."       ║
    ║     "Dữ liệu mô tả quá khứ. Cảm giác biết hiện tại."    ║
    ║                                                            ║
    ╚═══════════════════════════════════════════════════════════╝

* * *

# Chapter 7 — The 90-Day Creed Experiment

* * *

| 🇺🇸 English |
| --- |
| **The full experiment.** Over 90 days, run all 5 lie-experiments sequentially. Each lie gets 18 days: 3 days prep, 12 days testing (the 21-day test compressed), 3 days reflection. The output is your *personal creed* — the 5.0+ philosophy as your body has tested it. |
| **Day 1-3 — Prep.** Read the lie's card. Identify ONE specific feature to test. Set up the test environment (partner for some, video for others, journal template). |
| **Day 4-9 — Test phase 1 (Copy).** Implement the orthodox way. Hit 50/day. Journal. |
| **Day 10-15 — Test phase 2 (Opposite).** Implement the inverse. Hit 50/day. Journal. |
| **Day 16-18 — Reflection.** Compare phase 1 vs phase 2 vs the unforced version (your body's natural tendency). Write your counter-credential. |
| **The 90-day calendar.** |
| **Days 1-18 — Lie #1 (Copy the Pros).** Forehand feature test. |
| **Days 19-36 — Lie #2 (Perfect Form).** 5-pro study + 14-day essentials-only hitting. |
| **Days 37-54 — Lie #3 (10,000 Hours).** 100-hour audit + deliberate-vs-filler split + redesign. |
| **Days 55-72 — Lie #4 (Coach Knows Best).** 5-coach study (if budget allows) or 1 coach × 5 sessions. |
| **Days 73-90 — Lie #5 (Feel vs Data).** Blindfold feel test + video calibration + decision rules. |
| **Day 91 — The synthesis.** Read all 5 counter-credentials. Write your 5.0+ personal creed (one paragraph). Compare to the manual's creed. Revise. |

* * *

# Chapter 8 — The Counter-Credential Vault

* * *

| 🇺🇸 English |
| --- |
| **What a counter-credential is.** A counter-credential is a single sentence that REPLACES the orthodox advice for YOUR body. It is not a generic principle. It is *your* tested finding. It is the most valuable sentence you can write — more valuable than any tip from any pro. |
| **The 5 counter-credentials to fill in (template).** |
| **Lie #1 — Copy the pros.** My counter-credential: "When I copied Alcaraz's take-back height, my contact point dropped 15cm. My counter-credential is _______________." |
| **Lie #2 — Perfect form.** My counter-credential: "Watching 5 pros, my functional essentials are chest turn / contact in front / follow-through to target. My style choices are _______________." |
| **Lie #3 — 10,000 hours.** My counter-credential: "I practiced 280 hours last year. 30 hours were deliberate. I am a 30-hour player. My plan is _______________." |
| **Lie #4 — Coach knows best.** My counter-credential: "5 coaches gave me 5 different diagnoses. My counter-credential is that I am my own best coach for fine-tuning. The external coach is for _______________." |
| **Lie #5 — Feel vs data.** My counter-credential: "My feel-outcome correlation is r = _____. I trust feel when _____, data when _______." |
| **Where to keep the vault.** The counter-credentials are your most valuable tennis artifacts. Save them in: (1) the first page of your journal, (2) a phone note titled "5.0+ creed," (3) a card in your tennis bag. They are your system's roots. |

* * *

# Chapter 9 — Your Anti-Orthodox Compass

* * *

| 🇺🇸 English |
| --- |
| **The full compass card.** This is what you print, fold, and carry. It summarizes the 5 lies, the 5 counter-credentials, and the 5.0+ creed in one place. When you are mid-match, mid-doubt, mid-coaching, this card is your anchor. |

### 📋 Deep-Dive #1 Master Card — Printable / Thẻ Tổng Deep-Dive #1

    ╔═══════════════════════════════════════════════════════════════╗
    ║  THE ANTI-ORTHODOX COMPASS — YOUR 5 COUNTER-CREDENTIALS       ║
    ║  LA BÀN PHẢN GIÁO ĐIỀU — 5 PHẢN-TÍN-CHỨNG CỦA BẠN           ║
    ╠═══════════════════════════════════════════════════════════════╣
    ║                                                                ║
    ║  LIE #1 — "COPY THE PROS" / NÓI DỐI #1 — "BẮT CHƯỚC PRO"    ║
    ║  My counter-credential / Phản-tín-chứng của tôi:             ║
    ║  __________________________________________________________    ║
    ║                                                                ║
    ║  LIE #2 — "PERFECT FORM" / NÓI DỐI #2 — "HÌNH THỨC HOÀN HẢO"║
    ║  My counter-credential / Phản-tín-chứng của tôi:             ║
    ║  __________________________________________________________    ║
    ║                                                                ║
    ║  LIE #3 — "10,000 HOURS" / NÓI DỐI #3 — "10.000 GIỜ"        ║
    ║  My counter-credential / Phản-tín-chứng của tôi:             ║
    ║  __________________________________________________________    ║
    ║                                                                ║
    ║  LIE #4 — "COACH KNOWS BEST" / NÓI DỐI #4 — "HLV BIẾT NHẤT"║
    ║  My counter-credential / Phản-tín-chứng của tôi:             ║
    ║  __________________________________________________________    ║
    ║                                                                ║
    ║  LIE #5 — "FEEL IS ENEMY OF SCIENCE" / NÓI DỐI #5            ║
    ║  My counter-credential / Phản-tín-chứng của tôi:             ║
    ║  __________________________________________________________    ║
    ║                                                                ║
    ╠═══════════════════════════════════════════════════════════════╣
    ║                                                                ║
    ║  THE 5.0+ PERSONAL CREED / TUYÊN NGÔN CÁ NHÂN 5.0+            ║
    ║  (Write your one paragraph here. Mine is unique to me.)        ║
    ║  (Viết đoạn của anh ở đây. Của tôi là duy nhất với tôi.)     ║
    ║                                                                ║
    ║  __________________________________________________________    ║
    ║  __________________________________________________________    ║
    ║  __________________________________________________________    ║
    ║  __________________________________________________________    ║
    ║                                                                ║
    ╠═══════════════════════════════════════════════════════════════╣
    ║                                                                ║
    ║  THE MASTER CUE / CÂU NHẮC TỔNG:                              ║
    ║     "I do not copy. I discover."                               ║
    ║     "Tôi không bắt chước. Tôi khám phá."                      ║
    ║                                                                ║
    ╚═══════════════════════════════════════════════════════════════╝


    ╔═══════════════════════════════════════════════════════════════╗
    ║  THE ANTI-ORTHODOX COMPASS — YOUR 5 COUNTER-CREDENTIALS       ║
    ║  LA BÀN PHẢN GIÁO ĐIỀU — 5 PHẢN-TÍN-CHỨNG CỦA BẠN           ║
    ╠═══════════════════════════════════════════════════════════════╣
    ║                                                                ║
    ║  LIE #1 — "COPY THE PROS" / NÓI DỐI #1 — "BẮT CHƯỚC PRO"    ║
    ║  My counter-credential / Phản-tín-chứng của tôi:             ║
    ║  __________________________________________________________    ║
    ║                                                                ║
    ║  LIE #2 — "PERFECT FORM" / NÓI DỐI #2 — "HÌNH THỨC HOÀN HẢO"║
    ║  My counter-credential / Phản-tín-chứng của tôi:             ║
    ║  __________________________________________________________    ║
    ║                                                                ║
    ║  LIE #3 — "10,000 HOURS" / NÓI DỐI #3 — "10.000 GIỜ"        ║
    ║  My counter-credential / Phản-tín-chứng của tôi:             ║
    ║  __________________________________________________________    ║
    ║                                                                ║
    ║  LIE #4 — "COACH KNOWS BEST" / NÓI DỐI #4 — "HLV BIẾT NHẤT"║
    ║  My counter-credential / Phản-tín-chứng của tôi:             ║
    ║  __________________________________________________________    ║
    ║                                                                ║
    ║  LIE #5 — "FEEL IS ENEMY OF SCIENCE" / NÓI DỐI #5            ║
    ║  My counter-credential / Phản-tín-chứng của tôi:             ║
    ║  __________________________________________________________    ║
    ║                                                                ║
    ╠═══════════════════════════════════════════════════════════════╣
    ║                                                                ║
    ║  THE 5.0+ PERSONAL CREED / TUYÊN NGÔN CÁ NHÂN 5.0+            ║
    ║  (Write your one paragraph here. Mine is unique to me.)        ║
    ║  (Viết đoạn của anh ở đây. Của tôi là duy nhất với tôi.)     ║
    ║                                                                ║
    ║  __________________________________________________________    ║
    ║  __________________________________________________________    ║
    ║  __________________________________________________________    ║
    ║  __________________________________________________________    ║
    ║                                                                ║
    ╠═══════════════════════════════════════════════════════════════╣
    ║                                                                ║
    ║  THE MASTER CUE / CÂU NHẮC TỔNG:                              ║
    ║     "I do not copy. I discover."                               ║
    ║     "Tôi không bắt chước. Tôi khám phá."                      ║
    ║                                                                ║
    ╚═══════════════════════════════════════════════════════════════╝

---

## 🎯 FINAL WORD / LỜI CUỐI

| 🇺🇸 English |
| --- |
| You started this deep-dive believing (perhaps unconsciously) at least one of the 5 orthodox lies. By the time you finish the 90-day experiment, you will know exactly which lies you were obeying — and you will have replaced each with a tested counter-credential. The first step toward the 5.0+ creed is *not believing the manual.* The first step is *not believing the orthodox.* The first step is *running the experiment and trusting your body's answer.* |

---

**Sources / Nguồn:**

- Tennis Research with Kwen-Ollama.md (Ch 1.6, 2.4, 6.4, 12.4) — the anti-orthodoxy framing, "không có cú forehand duy nhất đúng cho tất cả mọi người," body-first cognition, self-coaching.
- Tennis Research - Neuro athletics - with Kwen-Ollama.md (Ch 3.10 ecological dynamics, Ch 5.8 elite models, Ch 3.1 myelination) — Bernstein's degrees of freedom, the "constraint-led approach," Vygotsky's zone of proximal development.
- Futuristic Tennis Manual by Olama.md (Integrated Master System, Ch 4 APS) — "Adaptive Intelligence," "trang thái hiệu suất thích ứng" applied to orthodoxy-vs-self-discovery.
- Advanced Tennis Kinetic-Chain Manual.md (Evolution Tables: 2000-10 vs 2020-26) — the historical shift from "imitation of pros" to "dictate geometry" tactical era.

**See you on the court, engineer.** / **Hẹn gặp trên sân, kỹ sư.**
