# Bảng Tóm Tắt Slice — Người Bạn Đồng Hành Trong Túi Vợt

## Nền Tảng Cơ Bản

Dù bạn dùng slice trong tình huống nào — bóng thấp, trả giao bóng, tiếp cận lưới, hay phòng thủ — năm điều này luôn không đổi:

- **Grip:** Continental, chữ V nằm trên bevel #2.
- **Mặt vợt:** Mở như mui xe, 30-45°.
- **Đường vung:** Cao xuống thấp (hoặc phẳng-tiến-tới với bóng thấp).
- **Âm thanh:** Lắng nghe tiếng "fwoosh" — đó là độ xoáy dưới sạch. Tiếng "thwack" nghĩa là bạn đánh phẳng.
- **Lực nắm vợt:** Tay mềm, 3-4 trên thang điểm 10. Tiếp xúc chắc, grip thả lỏng — đó chính là nghịch lý làm nên hiệu quả.

## Hiểu Rõ Tình Huống Của Bạn

| Tình huống | Hành động của bạn | Tín hiệu |
|---|---|---|
| **Bóng thấp** | Múc & trượt | Ngực xuống ngang bóng — gập gối, không gập lưng |
| **Trả giao bóng** | Chặn & đổi hướng | Không vung — dùng lực của họ, không phải của bạn |
| **Tiếp cận lưới** | Slice thấp, tiến lên | Cắt sâu, split-step, và tiến lên |
| **Phòng thủ** | Chỉ cần đưa sâu | Bạn đang mua thời gian — đừng nhắm sát biên |

## Danh Sách An Toàn Của Bạn

- **Bảo vệ lưng.** Gập gối khi đánh bóng thấp. Không bao giờ gập lưng.
- **Bảo vệ vai.** Nếu vai cảm thấy căng, hãy dựa vào cú hai tay để tạo lực và dành slice cho mọi tình huống còn lại.
- **Kiểm soát bước lao.** Những bước nhỏ, có kiểm soát luôn tốt hơn một cú lao đột ngột — đó chính là nguyên nhân gây căng đầu gối.
- **Giữ grip mềm.** Một cú nắm vợt chặt là cách biến lực va chạm của bóng thành chấn thương. Thả lỏng bàn tay và để nó hấp thụ lực thay vì chống lại nó.

---

*Slice là bảo hiểm của bạn. Khi nghi ngờ, hãy slice sâu và thở đều.*
