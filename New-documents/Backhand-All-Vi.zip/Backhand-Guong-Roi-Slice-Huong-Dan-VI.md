# Backhand — Tấm Gương, Cây Roi, và Slice

## Chương 1 — Ý Tưởng Lớn: Backhand Của Bạn Là Một Tấm Gương

Hãy xem bất kỳ người chơi giỏi nào đánh backhand và bạn sẽ nhận ra điều này: tư thế chuẩn bị trông gần giống hệt cú thuận tay. Cùng pha xoay người, cùng sự xoay ngực, cùng điểm tiếp xúc phía trước. Điều duy nhất thay đổi là hướng.

Đó là sự thay đổi tư duy tôi muốn bạn thực hiện. Hầu hết người chơi ở trình độ của bạn coi backhand như một cú đánh hoàn toàn khác. Họ vung bằng cánh tay thay vì xoay ngực. Họ nhìn **vào** bóng thay vì nhìn xuyên qua nó. Họ chậm lại và trở nên rụt rè vì cả cú đánh này "cảm giác kỳ lạ."

Không nên cảm giác như một môn thể thao khác. Cùng hệ thống bốn lớp chi phối cú thuận tay của bạn — cú vung, tư thế chuẩn bị, trục xoay, và cảm giác — áp dụng đầy đủ ở đây. Đổi hướng, và mọi thứ khác vẫn giữ nguyên.

Đây là một cách để cảm nhận điều đó: đứng trước gương và đánh một cú thuận tay. Bây giờ hãy phản chiếu chuyển động đó — cùng xoay, cùng chuyển trọng lượng, cùng kết thúc, chỉ là vợt nằm ở phía bên kia. Cơ thể bạn thực ra không biết từ "thuận tay" hay "trái tay". Nó chỉ biết một nguyên tắc: ngực xoay, cánh tay theo sau, bóng đi. Bên nào không quan trọng đối với nguyên tắc đó.

### Hai Khác Biệt Thực Sự

Có đúng hai điều thực sự thay đổi giữa hai bên, và chúng đáng để biết chính xác.

**Thứ nhất — tay thuận vẫn dẫn dắt, nhưng giờ nó có bạn đồng hành.** Ở backhand hai tay, tay phải của bạn (nếu bạn thuận tay phải) vẫn là động cơ tạo ra cú đánh. Nhưng tay trái của bạn giờ cũng ở trên vợt, đóng vai trò như một điểm tựa hơn là một động cơ. Nó ổn định; tay phải bạn tăng tốc. Đó là ngược lại với cảm giác tự nhiên lúc đầu, nên cần thời gian để làm quen.

**Thứ hai — cú kết thúc ở vai đối diện.** Cú thuận tay của bạn kết thúc trên vai phải. Backhand hai tay của bạn kết thúc trên vai trái. Chi tiết duy nhất này là dấu hiệu hình ảnh rõ ràng nhất cho việc bạn có đang đánh cú này đúng cách hay không.

Tôi thích nghĩ về cú thuận và cú trái như hai chương phản chiếu của cùng một cuốn sách — mở sang phải (thuận tay) và bạn có "chương kết thúc vai phải", lật sang trái (trái tay) và bạn có "chương kết thúc vai trái." Cùng một cuốn sách, chương phản chiếu.

**Sai lầm tôi thấy liên tục:** người chơi kết thúc backhand của họ trên **cùng** vai với cú thuận tay — vai phải. Điều đó tạo ra một cú đánh yếu, giật cổ tay, không có lực thực sự. Đây cũng là điều dễ chẩn đoán nhất từ ngoài đường biên. Nếu backhand của bạn liên tục kết thúc trên vai phải, ngực bạn đơn giản là không xoay đủ. Hãy quay lại và thiết lập lại pha xoay người.

---

## Chương 2 — Backhand Hai Tay: Cú Đánh Hàng Ngày Của Bạn

Với một người chơi ở trình độ và tuổi tác của bạn, backhand hai tay là lựa chọn đúng đắn. Nó ổn định, tạo ra lực thực sự, và nhẹ nhàng với vai. Chuỗi động học giống hệt với cú thuận tay bạn đã biết — chúng ta chỉ áp dụng nó cụ thể cho bên này.

### Grip

Hai tay của bạn làm những công việc khác nhau, nên chúng dùng grip khác nhau.

**Tay thuận** của bạn (phải, nếu thuận tay phải) dùng cùng grip với cú thuận tay của bạn — Semi-Western hoặc Eastern, với chữ V giữa ngón cái và ngón trỏ nằm trên bevel #4 hoặc #3.

**Tay không thuận** của bạn dùng Continental — bevel #2, cùng grip với volley của bạn. Tay đó ở đó chỉ để ổn định, không phải để thêm topspin.

Tại sao Continental cụ thể trên tay trái? Nó giữ mặt vợt hơi đóng lại một chút khi tiếp xúc, đúng là những gì bạn muốn. Nếu bạn dùng Eastern hoặc Semi-Western trên tay đó thay vào đó, mặt vợt sẽ mở quá nhiều khi tiếp xúc và bóng sẽ bay quá dài.

Sai lầm phổ biến nhất tôi thấy ở trình độ của bạn là dùng cùng grip trên cả hai tay — thường là Semi-Western trên cả hai. Điều đó khóa mặt vợt mở khi tiếp xúc, làm mất lực, và có lẽ là lý do số một khiến backhand nghiệp dư của người chơi bay dài qua vạch cuối sân.

### Pha Xoay Người

Pha xoay người backhand của bạn là pha xoay người cú thuận tay của bạn, được phản chiếu — vai xoay sang phải thay vì trái, cằm nghỉ trên vai phải, cả hai tay đến cùng nhau lên tầm ngực với tay trái bạn ở cổ vợt.

Từ vị trí ngang ngực đó, cả hai tay hạ xuống cùng nhau khi vai bạn xoay, và đầu vợt vẫn ở trên cao và hơi ra sau bạn — tạo thành một hình dạng hơi giống chữ D so với cơ thể bạn.

Đây là một cách kiểm tra hữu ích: đứng trước gương và thực hiện pha xoay người thuận tay — cằm trên vai trái, đầu vợt lên cao. Bây giờ thực hiện pha xoay trái tay — cằm trên vai phải, đầu vợt lên cao. Cả hai nên trông giống hình ảnh phản chiếu của nhau. Nếu pha xoay trái tay của bạn trông nông hơn, chậm hơn, hoặc kém cam kết hơn pha xoay thuận tay, đó chính xác là nơi vấn đề của bạn bắt đầu.

### Sự Xoay: Ngực Xoay, Cả Hai Vai Di Chuyển

Đây là lớp mà hầu hết người chơi bỏ lỡ hoàn toàn. Một backhand hai tay không thực sự là một cú vung bằng hai cánh tay — nó là một sự xoay ngực với hai tay tình cờ ở trên vợt. Ngực xoay, cả hai vai di chuyển cùng nhau như một khối, và cánh tay bạn phần lớn chỉ đi theo.

Ở bên này, các vai trò đảo ngược từ cú thuận tay của bạn: bên trái của bạn trở thành trục vững chãi, có trọng lượng, và bên phải của bạn là bên tự do di chuyển. Sau một cú tiếp xúc tốt, cả hai vai bạn nên hướng vuông góc với lưới, ngực mở hoàn toàn. Nếu vai phải bạn vẫn hướng sang một bên sau khi bạn đã đánh bóng, ngực bạn đơn giản là không xoay đủ xa.

### Cú Vung: Cùng Hình "L", Cú Rơi Được Phản Chiếu

Hình dạng cánh tay gập mà bạn dùng ở pha chuẩn bị cú thuận tay cũng xuất hiện ở đây — góc giữa cẳng tay phải và cán vợt nên giữ gập gần như cho đến khi tiếp xúc. Duỗi thẳng nó quá sớm là cùng sai lầm ở đây như ở cú thuận tay, và nó cũng phổ biến không kém.

Cùng nhịp 70/30 áp dụng: bảy mươi phần trăm cú vung chậm và tích lũy, ba mươi phần trăm nhanh qua tiếp xúc. Và cú rơi cũng được phản chiếu — nơi vợt cú thuận tay của bạn rơi ra sau lưng dưới cổ tay, vợt backhand của bạn rơi sang bên trái, dưới cổ tay. Cùng nguyên tắc cơ bản dù bên nào: đầu vợt rơi theo trọng lượng của chính nó. Bạn không kéo nó xuống bằng cánh tay.

### Tiếp Xúc và Kết Thúc

Tiếp xúc xảy ra ở tầm cánh tay duỗi thẳng, phía trước chân trước, khoảng ngang eo-ngực. Khi vợt giải phóng qua bóng, cẳng tay phải bạn lăn nhẹ để thêm topspin.

Cú kết thúc chính là dấu hiệu: vợt kết thúc cao trên vai trái, đầu vợt chỉ lên và ra sau. Nếu nó kết thúc trên vai phải thay vào đó, ngực bạn đơn giản là không xoay xuyên qua cú đánh. Tổng khoảng cách theo bóng ngắn hơn cú thuận tay của bạn — khoảng một mét rưỡi — và hai tay bạn nên ở cùng nhau suốt cả quãng đường.

Một thói quen tôi muốn bạn tránh xa: cố thêm lực bằng cách "giật" cổ tay khi tiếp xúc. Cảm giác tự nhiên, nhưng đó là nguồn lực sai cho cú đánh này — backhand hai tay lấy gần như toàn bộ lực từ sự xoay ngực, không phải cổ tay. Một backhand giật cổ tay cũng là con đường phổ biến dẫn đến đau khuỷu tay ở cánh tay không thuận (bên đỡ vợt).

**Bài tập — Giữ Vòng D.** Đứng trước gương và thực hiện pha xoay người backhand: cả hai tay cùng nhau ở tầm ngực, cả hai vai xoay sang phải, đầu vợt lên cao. Giữ hình dạng đó trong hai giây trọn vẹn. Kiểm tra bản thân — cằm trên vai phải? Đầu vợt lên cao? Cả hai tay cùng nhau? Khuỷu tay hạ xuống? Mười lần lặp mỗi ngày là đủ để cơ thể bạn bắt đầu coi tư thế này với cùng sự cam kết như cú thuận tay.

**Bài tập — Kiểm Tra Kết Thúc Vai Trái.** Nhờ một người bạn xem bạn đánh mười cú backhand. Việc duy nhất của họ là cho bạn biết vợt kết thúc trên vai nào. Nếu tám hoặc nhiều hơn kết thúc trên vai trái, ngực bạn đang xoay đúng. Nếu hầu hết kết thúc trên vai phải, bạn đang vung bằng cánh tay — ngực bạn không làm việc của nó. Đây thành thật là bài kiểm tra chẩn đoán tốt nhất cho cú đánh này.

---

## Chương 3 — Backhand Một Tay: Điều Cần Biết, Điều Nên Học

Backhand một tay có lẽ là cú đánh đẹp nhất trong tennis. Wawrinka, Federer, Dimitrov, Gasquet, Thiem — họ đều đánh nó khác nhau, và mỗi người trong số họ đánh nó thật đẹp.

Nhưng nó cũng là cú đánh gây căng thẳng cho vai nhất trong môn thể thao này. Nó đòi hỏi timing chính xác, footwork xuất sắc, và một cái vai có thể chịu được tải trọng lặp đi lặp lại về một phía.

Với hầu hết người chơi ở giai đoạn của bạn, backhand hai tay vẫn là lựa chọn hợp lý hàng ngày. Chương này dành cho hai nhóm: người chơi đã đánh backhand một tay và muốn cải thiện nó, và người chơi muốn thêm slice một tay cụ thể — nó nhẹ nhàng hơn nhiều với vai so với người anh em topspin của nó.

### Ba Bậc Thầy, Ba Cách Tiếp Cận

**Vòng lặp C mượt mà của Dimitrov:** một pha xoay người sâu, đầu vợt rơi bên dưới bóng theo một hình chữ C lớn, tiếp xúc phía trước với cánh tay duỗi ra. Lực đến từ xoay hông và cú bật đàn hồi của vòng lặp đó. Nó trông như lụa.

**Phong cách tuyến tính bùng nổ của Wawrinka:** chuẩn bị sớm và tích cực, khuỷu tay trái kéo sâu ra sau lưng, chuyển trọng lượng tuyến tính với chân trước hướng khoảng 45 độ so với lưới. Lực đến từ sự mở của thân trên, không phải cánh tay. Nó nghe như một tiếng đại bác.

**Phiên bản gọn gàng, hiệu quả của Federer:** pha chuẩn bị gọn gàng vào vị trí slot (đầu vợt dưới bóng), cánh tay gần như thẳng khi tiếp xúc, bước gót-tới-mũi vào cú đánh, và sự ổn định đầu đáng kinh ngạc — mắt khóa vào điểm tiếp xúc trong khoảng 0.2 giây sau va chạm. Lực ở đây đến từ độ chính xác, không phải kích cỡ.

Thành thật mà nói, không cái nào trong số này hoàn toàn đúng để bạn sao chép toàn bộ — mỗi tay vợt chuyên nghiệp đã bỏ ra hơn mười lăm năm rèn luyện cụ thể mà cơ thể bạn chưa có. Điều thực sự đáng để học:

- **Cú rơi vòng lặp C của Dimitrov** — cảm giác để đầu vợt rơi thay vì kéo nó về sau. Dễ sao chép, thực sự hữu ích.
- **Cú kéo khuỷu tay sâu của Wawrinka** — đây là động cơ xoay của anh, nhưng là một bản sao khó khăn, rủi ro ở tuổi của bạn. Tôi sẽ để nó yên.
- **Ánh mắt tĩnh và footwork gót-tới-mũi của Federer** — lợi ích hiệu quả thuần túy. Chúng bảo vệ vai và đôi chân bạn trong khi vẫn cải thiện cú đánh.

### Grip

Continental, không ngoại lệ. Bất cứ thứ gì mở hơn — Eastern hoặc Semi-Western — buộc mặt vợt mở khi tiếp xúc và đưa bóng bay dài. Chữ V giữa ngón cái và ngón trỏ nằm trên bevel #2, cùng với grip volley của bạn.

### Footwork

Chân phải của bạn (với người thuận tay phải) bước vào bằng gót trước, rồi lăn lên mũi khi bạn tải vào cú đánh. Kiểu gót-tới-mũi này cho bạn một nền tảng ổn định và một chút lực đẩy lên qua tiếp xúc. Đây là lựa chọn footwork an toàn nhất ở tuổi của bạn chính xác vì nó nhỏ và có kiểm soát — không lao người, không với quá xa, không dừng đột ngột. Đầu gối bạn hấp thụ tải trọng dần dần thay vì tất cả cùng một lúc.

### Ánh Mắt Tĩnh

Sau khi tiếp xúc, giữ mắt bạn ở điểm tiếp xúc trong khoảng hai phần mười giây — đầu bạn hầu như không di chuyển. Khoảng dừng ngắn đó cho não bạn thêm thời gian để xử lý chính xác điều vừa xảy ra khi tiếp xúc, giúp cú đánh tiếp theo của bạn sắc bén hơn. Nó không tốn gì và có lẽ là cải thiện nhanh nhất có sẵn cho bạn. Trong tập luyện, hãy thử giữ đầu tĩnh trong một tiếng đếm "một Mississippi" chậm sau mỗi cú đánh trước khi bạn xoay để theo dõi quả bóng tiếp theo.

**Nếu vai bạn có tiền sử thực sự** — va chạm khớp, căng cơ chóp xoay, cứng mãn tính — hãy giữ với backhand hai tay cho bất cứ điều gì cần lực, và dành cú một tay hoàn toàn cho slice, thực sự nhẹ nhàng với vai. Hãy hỏi vai bạn trước khi hỏi cái tôi của bạn.

---

## Chương 4 — Slice Backhand: Chiến Mã Của Bạn Trên 50 Tuổi

Slice backhand có lẽ là cú đánh bị đánh giá thấp nhất trong tennis nghiệp dư. Nó giữ thấp sau khi nảy, mua thêm thời gian cho bạn, phá vỡ nhịp điệu của đối thủ, và nó nhẹ nhàng với vai. Nó hoạt động trong phòng thủ, trên bóng thấp, làm cú tiếp cận lưới, và chống lại các cú giao bóng mạnh bạn không thể áp đảo.

Hãy coi nó như bảo hiểm của bạn. Ngay cả vào ngày backhand hai tay của bạn cảm thấy tuyệt vời, sẽ có những ngày khác mà vai, khuỷu tay, hoặc lưng bạn chỉ đơn giản nói "không phải hôm nay." Vào những ngày đó, slice là cú đánh giữ bạn ở lại trên sân thay vì ngồi ngoài.

### Grip

Với slice hai tay, cả hai tay dùng Continental — V trên bevel #2 cho cả hai. Với slice một tay (phiên bản thanh lịch hơn, gần với phong cách Federer), chỉ tay phải bạn ở trên vợt, cùng grip Continental bạn dùng cho volley.

Dù bằng cách nào, mặt vợt nên mở như mui xe — nghiêng lên khoảng 30 đến 45 độ so với phương thẳng đứng, như thể mặt vợt là mui một chiếc xe hướng lên trời.

### Chuyển Động: Mở Cửa, Bước Qua

Hãy nghĩ toàn bộ cú vung như một cánh cửa. Pha chuẩn bị là cánh cửa mở ra — vợt lên cao, trên vai bạn. Cú vung là cánh cửa đóng lại — vợt đi xuống và ngang qua cơ thể bạn, mặt vợt giữ mở suốt cả thời gian, tiếp xúc xảy ra ở đâu đó giữa cung đó, trên đường xuống. Bạn bước qua cánh cửa vào khoảnh khắc tiếp xúc.

Cue quan trọng nhất ở đây: **slice tiếp xúc bóng từ bên dưới, không phải từ trên.** Đường đi từ cao xuống thấp, cắt bên dưới bóng, điều này tạo ra độ xoáy ngược làm bóng giữ thấp sau khi nảy.

Nó rất giống với một cần gạt nước kính chắn gió — điểm cao ở một đầu, kết thúc thấp ở đầu kia, mặt vợt nghiêng suốt cả thời gian, tiếp xúc xảy ra ở đâu đó giữa cung khi nó đi qua.

### Tiếp Xúc và Kết Thúc

Tiếp xúc xảy ra khoảng ngang eo, hơi phía trước chân trước, trên đường xuống — bạn đang "cắt" bóng từ bên dưới. Cú kết thúc đến thấp, ngang qua cơ thể, đầu vợt kết thúc gần hông đối diện với nơi nó bắt đầu, với trọng lượng cơ thể bạn đã chuyển hoàn toàn về phía trước.

Đây là nghịch lý đáng nhớ: lực nắm vợt của bạn nên mềm — ba hoặc bốn trên thang điểm mười — nhưng bản thân tiếp xúc nên cảm thấy chắc, dây vợt không nhượng bộ nhiều khi va chạm. Tay thả lỏng, va chạm chắc chắn. Sự kết hợp đó chính là điều thực sự tạo ra độ xoáy dưới sạch.

**Ba lỗi tôi thấy nhiều nhất:**
- **Vung lên vào bóng**, tạo ra một cú bóng trôi yếu ớt thay vì một slice có kiểm soát. Đường đi là xuống, không phải lên.
- **Đóng mặt vợt khi tiếp xúc**, khiến bóng lao thẳng vào lưới. Giữ mặt vợt mở suốt cả thời gian.
- **Vung quá mạnh.** Đây là một cú đánh đặt bóng, không phải cú đánh tạo lực — hãy để độ xoáy dưới làm việc thay vì dùng sức.

### Khi Nào Nên Dùng Nó

- **Dưới áp lực:** chỉ cần đưa nó trở lại sâu, không cần lực. Bạn đang mua thời gian để hồi vị trí.
- **Làm cú tiếp cận lưới:** một slice thấp buộc đối thủ vào một câu trả lời khó chịu — họ không thể đánh mạnh một quả bóng thấp — trong khi bạn tiến lên phía sau nó.
- **Chống lại một cú giao bóng mạnh:** độ xoáy dưới hấp thụ lực và bóng rơi ngắn, lấy đi thời gian của người giao bóng vốn đang mong đợi làm chủ điểm số.
- **Để phá vỡ nhịp điệu:** chèn một cú slice sau một chuỗi rally topspin. Sự thay đổi độ xoáy làm rối timing của đối thủ nhiều hơn bạn nghĩ.

**Bài tập — Rally Tường 20 Cú Slice.** Đứng cách tường khoảng 4 mét và rally chỉ với slice, nhịp độ chậm. Mục tiêu: 20 quả bóng liên tiếp nảy dưới tầm eo bên phía bạn. Lắng nghe âm thanh — một cú slice sạch nghe như tiếng "fwoosh" nhẹ nhàng; một cú đánh phẳng hơn nghe giống tiếng "thwack." Nếu 20 quá dễ, lùi ra 5 mét. Nếu 10 quá khó, tiến vào 3 mét.

**Bài tập — Slice Rồi Tiến Lên.** Nhờ một người bạn rally topspin với bạn từ vạch cuối sân. Mỗi năm quả bóng, đánh một cú slice thay vì topspin, và ngay khoảnh khắc vợt bạn chạm bóng, split-step và di chuyển về phía trước tiến tới lưới. Slice giữ bóng thấp, điều này buộc đối thủ vào một cú slice hoặc lốp phòng thủ của riêng họ — cho bạn thời gian để tiến gần. Nhắm tới 5 trên 10 lần tiếp cận mà bạn thực sự tới được lưới và volley được quả bóng tiếp theo.

---

## Chương 5 — Bài Tập, Lỗi Thường Gặp, và Bảng Kiểm Tra Thực Tế Cho Người Trên 50

### Năm Bài Tập Để Đưa Vào Tuần Của Bạn

1. **Rally Tường Chéo Tay** — hàng ngày, 5 phút. Rally cú thuận topspin (cú thuận tay bình thường của bạn) trước tường trong 10 quả, sau đó chuyển sang backhand hai tay mà không đổi vị trí chân. Rally thêm 10 quả nữa. Tường không quan tâm bên nào — bài tập này dạy cơ thể bạn rằng "nhịp điệu thuận tay" và "nhịp điệu trái tay" là cùng một nhịp điệu, chỉ được phản chiếu. Mục tiêu: 20 cú trái tay liên tiếp.

2. **Kiểm Tra Kết Thúc Vai Trái** — hàng tuần, 5 phút. Nhờ một người bạn xem 10 cú backhand. Việc duy nhất của họ là cho bạn biết vợt kết thúc trên vai nào. Mục tiêu 8 trên 10 lần kết thúc trên vai trái. Nếu bạn dưới 5, hãy tạm bỏ cú hai tay trong một tuần, thực hiện bài tập Giữ Vòng D hàng ngày, và xây dựng lại pha xoay.

3. **Rally Tường Slice** — 3 lần một tuần, 10 phút. Hai mươi cú slice liên tiếp nảy dưới tầm eo trước tường.

4. **Shadow Swing "Tấm Gương"** — hàng ngày, 3 phút. Không bóng, thực hiện một cú thuận tay chuyển động chậm. Rồi một cú trái tay chuyển động chậm. Rồi thuận tay. Rồi trái tay. Xen kẽ trong ba phút. Mục tiêu: cơ thể học rằng cả hai cú đánh dùng CÙNG nhịp pha xoay người — chỉ được phản chiếu. Sự xoay ngực, cú rơi hình L, sự tăng tốc muộn — tất cả đều giống nhau. Chú ý tới "phía sau" của pha xoay người. Cú thuận tay: cằm trên vai trái. Cú trái tay: cằm trên vai phải. Cả hai nên trông giống nhau.

5. **Luyện Tập Ánh Mắt Tĩnh** — hàng tuần, trên sân. Trong tập luyện thông thường, sau MỖI cú đánh — thuận tay, trái tay, volley, giao bóng — giữ đầu bạn tĩnh và đếm "một Mississippi" trước khi xoay người. Nó sẽ cảm thấy kỳ lạ. Sẽ cảm thấy như bạn "lãng phí thời gian." Nhưng khoảnh khắc tĩnh lặng một giây đó là cải thiện rẻ nhất trong tennis.

### Bảy Lỗi Tôi Thấy Liên Tục

| Lỗi | Trông như thế nào | Cách sửa |
|---|---|---|
| Cùng grip cả hai tay | Semi-Western trên cả hai — mặt vợt quá mở | Continental trên tay không thuận (trái) |
| Kết thúc vai phải | Backhand kết thúc như một cú thuận — không có lực thực sự | Bài tập xoay ngực, kiểm tra kết thúc vai trái |
| Giật cổ tay | Cổ tay giật khi tiếp xúc để tìm thêm lực | Cue "khuỷu tay dẫn" — thử bài tập kẹp khăn dưới nách |
| Vung lên trên slice | Đường vợt đi từ thấp lên cao thay vì cao xuống thấp | "Slice = dưới bóng" — quan sát nó khi đánh tường |
| Đóng mặt vợt trên slice | Slice lao thẳng vào lưới | "Mở như mui xe" — kiểm tra grip Continental |
| Vung bằng cánh tay | Cả hai cánh tay đẩy, ngực đứng yên | "Ngực xoay, cánh tay theo sau" — shadow swing |
| Pha xoay nông | Pha xoay trái tay nhỏ hơn hoặc trễ hơn thuận tay | Bài tập Giữ Vòng D, kiểm tra trong gương |

### Bảng Kiểm Tra Thực Tế Cho Người Trên 50

- **Căng vai trên cú một tay** đến từ tải trọng một cánh tay lặp đi lặp lại. Dùng cú hai tay cho lực, giữ cú một tay chỉ cho slice.
- **Đau khuỷu tay ở tay không thuận** thường có nghĩa là tay đỡ đó đang nắm quá chặt với mặt vợt đóng. Nới lỏng nó xuống 3-4 trên 10 và ngừng siết chặt.
- **Căng cổ tay hướng về ngón cái** trên cú hai tay đến từ việc để cổ tay dẫn thay vì khuỷu tay. Giữ khuỷu tay dẫn, không giật cổ tay.
- **Vặn lưng dưới** thường xuất hiện từ pha xoay vai quá mức trên cú một tay. Dựa vào cú hai tay cho các bóng rộng và dành cú một tay cho bóng trung tính.
- **Đau đầu gối trên slice thấp** thường đến từ một cú gập gối sâu, dừng đột ngột. Giữ chân sau gập và mềm, và ưu tiên mặt sân mềm hơn khi bạn có lựa chọn.
- **Thời gian hồi phục:** các buổi tập một tay thường để lại vài ngày đau nhức. Giới hạn bản thân một buổi một tay mỗi tuần, chỉ slice, khi bạn đã qua 50 tuổi.
- **Sự rụt rè ở bên backhand** — tiếp xúc trễ sinh ra từ việc không tin tưởng cú đánh — phản ứng tốt với các bài tập gương hàng ngày giúp xây dựng lại niềm tin vào cùng hệ thống bốn lớp mà bạn đã biết từ cú thuận tay.

Quy tắc duy nhất tôi muốn bạn mang theo từ chương này: **backhand của bạn không phải là bên yếu của bạn. Đó là tấm gương của bạn.** Hãy đối xử với nó cùng sự tôn trọng như cú thuận tay — cùng sự cam kết với pha xoay người, cùng hệ thống bốn lớp, cùng đường kết thúc. Khoảnh khắc bạn bắt đầu nghĩ về nó như "bên tôi không thích," bạn đang nhường gần một phần ba sân đấu trước khi điểm số thậm chí bắt đầu.

---

## Bảng Tóm Tắt Nhanh

```
═══════════════════════════════════════════════════════════════
  BACKHAND — TÓM TẮT NHANH
═══════════════════════════════════════════════════════════════

  Ý TƯỞNG LỚN
  Backhand là một TẤM GƯƠNG, không phải một cú đánh khác.
  Ngực xoay, cánh tay theo sau, bóng đi. Bên nào không quan trọng.

  ───────────────────────────────────────────────────────────
  BACKHAND HAI TAY
  ───────────────────────────────────────────────────────────
  Grip tay thuận:        Giống cú thuận (Semi-W hoặc Eastern)
  Grip tay không thuận:  Continental (V trên bevel #2)
  Pha xoay người:        Cằm trên vai PHẢI (phản chiếu cú thuận)
  Cú rơi:                Đầu vợt rơi dưới cổ tay, phía trái
  Sự xoay:                CẢ HAI vai xoay cùng nhau
  Tiếp xúc:                Phía trước, tầm với hết cỡ, khuỷu tay dẫn
  Cổ tay:                  Khóa — không giật
  Kết thúc:                Trên vai TRÁI, không phải phải

  ───────────────────────────────────────────────────────────
  BACKHAND MỘT TAY
  ───────────────────────────────────────────────────────────
  Grip:                   Continental (V trên bevel #2)
  Pha chuẩn bị:            Vòng lặp C (Dimitrov) hoặc slot (Federer)
  Footwork:                Gót-tới-mũi (Federer)
  Tiếp xúc:                Khuỷu tay hơi gập, phía trước
  Đầu:                     Ánh mắt tĩnh — 0.2 giây sau tiếp xúc
  Lưu ý cho người 50+:     2HB cho lực, 1HB chỉ cho slice

  ───────────────────────────────────────────────────────────
  SLICE BACKHAND
  ───────────────────────────────────────────────────────────
  Grip:                    Continental, cả hai tay (hoặc 1HB)
  Pha chuẩn bị:            CAO ("cửa mở")
  Đường vung:              CAO xuống THẤP ("cửa đóng")
  Mặt vợt:                 Mở như mui xe, 30-45°
  Tiếp xúc:                Ngang eo, trên đường xuống
  Kết thúc:                Thấp, ngang qua cơ thể, gần hông đối diện
  Âm thanh:                "Fwoosh" = xoáy dưới sạch (tốt)

  ───────────────────────────────────────────────────────────
  DỪNG LẠI VÀ ĐIỀU CHỈNH NẾU
  ───────────────────────────────────────────────────────────
  • Đau vai hoặc khuỷu tay, đặc biệt trên cú một tay
  • Đau cổ tay ở tay không thuận (tay đỡ)
  • Backhand liên tục bay dài (mặt vợt mở, ngực không xoay)
  • Backhand liên tục lao vào lưới (mặt vợt đóng, vung bằng tay)
  • Backhand liên tục kết thúc trên vai phải
  • Đau lưng dưới sau khi đánh backhand

═══════════════════════════════════════════════════════════════
  Tennis là môn thể thao 20 năm. Hãy đối xử với backhand của
  bạn với cùng sự tôn trọng như cú thuận — nó là tấm gương của
  bạn, không phải bên yếu của bạn.
═══════════════════════════════════════════════════════════════
```
