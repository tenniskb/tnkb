# Slice Bóng Thấp — "Múc & Trượt"

Được rồi, hãy nói về cú đánh âm thầm phá hỏng nhiều trận đấu ở trình 3.5 nhất: bóng thấp.

Bạn biết cú đó rồi đấy. Bóng lướt vào dưới mép lưới, và phản xạ đầu tiên của bạn là cố nâng nó lên — tạo topspin, đánh trả có lực. Chín trên mười lần, bạn sẽ đánh hỏng vào lưới hoặc đưa bóng ra ngoài. Đây là sự thật: **bóng thấp không phải là cú đánh để bạn thắng điểm. Đó là cú đánh để bạn sống sót.** Slice chính là cách bạn sống sót qua nó.

## Tại Sao Ta Làm Vậy

Nếu bóng ở dưới đầu gối, hông của bạn không thể nào đưa cơ thể xuống kịp để thực hiện một cú topspin an toàn. Bạn đang chống lại quy luật hình học, và hình học luôn thắng.

Vậy nên đừng chống lại nó nữa. Hạ thấp người, xuống thấp, và trượt vợt xuống dưới bóng như thể bạn đang múc bóng lên khỏi mặt sân. Đó là toàn bộ ý tưởng. Đây không phải cú đánh phòng thủ vì bạn yếu — đây là cú đánh phòng thủ vì nó là **cú đánh thông minh.**

**Một lưu ý nếu bạn trên 50 tuổi:** đừng cố thi đấu thể lực với quả bóng này. Không lao người, không nhào lộn. Hạ thấp bằng đôi chân, trong tầm kiểm soát, mỗi lần đều vậy. Chúng ta sẽ quay lại điểm này sau.

## Kỹ Thuật: Múc & Trượt

**Bước 1 — Hạ ngực xuống ngang tầm bóng.**
Đây là chuyện của đầu gối, không phải của lưng. Gập gối đủ sâu để ngực bạn ở khoảng ngang với điểm tiếp xúc. Nếu bạn thấy mình gập ở thắt lưng thay vì gập gối, dừng lại ngay — đó là cách lưng bị chấn thương, và nó cũng làm mất thăng bằng đúng lúc bạn cần nó nhất.

**Bước 2 — Quên đi kiểu "cao xuống thấp".**
Đường vung slice thông thường sẽ không hiệu quả ở đây — nếu bạn vung cao xuống thấp với một quả bóng vốn đã thấp, vợt của bạn sẽ chỉ cắm thẳng xuống sân. Thay vào đó, hãy nghĩ **phẳng-tiến-tới**. Đầu vợt đi vào thấp và trượt **xuyên qua** bóng, gần giống như bạn đang xúc cát bằng xẻng.

**Bước 3 — Giữ mặt vợt mở và trượt bên dưới.**
Khi tiếp xúc bóng, hãy hình dung mặt vợt như một cái mui xe nhỏ nghiêng ra sau — khoảng 30 đến 45 độ mở. Đó chính là thứ tạo ra độ xoáy dưới giúp bóng ổn định. Bạn không chặt xuống bóng. Bạn đang trượt bên dưới nó và để bóng trượt theo mặt vợt ra ngoài.

## Bài Tập: Rally Tường Bóng Thấp

Đây là bài tập duy nhất thực sự sẽ khắc sâu cảm giác này vào đôi tay bạn, và bạn không cần bạn tập cũng làm được.

- Đứng cách tường khoảng 3 mét.
- Thả bóng thấp, và slice nó vào **1/4 dưới cùng** của tường.
- Tập trung vào duy nhất cảm giác múc bên dưới bóng.
- Mục tiêu: 10 cú slice sạch liên tiếp chạm vào phần dưới của tường.

**Tại sao dùng tường thay vì bạn tập?** Vì tường không bao giờ đánh trượt, không di chuyển, và không quan tâm đến cái tôi của bạn. Bạn nhận được phản hồi ngay lập tức — bạn có thể nghe được liệu mình đã làm đúng hay chưa. Và quan trọng không kém: bạn không phải học cảm giác này trong khi một chàng trai 25 tuổi đang đập bóng vào mắt cá chân bạn. Hãy làm chủ nó với tường trước. Mang nó ra sân sau.

## Làm Sao Biết Nó Đang Hiệu Quả

Hãy lắng nghe âm thanh tiếp xúc.

- **"Fwoosh"** — tiếp xúc sạch, trượt mượt, độ xoáy dưới tốt. Đó là âm thanh bạn muốn nghe.
- **"Thwack"** — đó là tiếng vợt chạm đất trước hoặc cùng lúc với bóng. Bạn đã hạ người quá thấp, hoặc đường vung sai. Đứng lại và thử lại.

Đôi tai của bạn thực ra sẽ dạy bạn cú đánh này nhanh hơn cả đôi mắt.

---

## Bảng Tóm Tắt Nhanh

```
═══════════════════════════════════════════
   SLICE BÓNG THẤP — TÓM TẮT NHANH
═══════════════════════════════════════════

  TƯ DUY
  Đừng chống lại bóng thấp. Hãy múc nó lên.

  1. HẠ NGƯỜI
     Gập gối, không gập lưng.
     Ngực ngang tầm bóng.

  2. ĐƯỜNG VUNG
     Phẳng-tiến-tới — không bao giờ cao-xuống-thấp.

  3. MẶT VỢT
     Mở như mui xe, 30–45°.

  4. LẮNG NGHE
     "Fwoosh" = sạch.  "Thwack" = quá thấp, đứng lại chỉnh.

  5. NẾU BẠN TRÊN 50 TUỔI
     Không lao người. Bước có kiểm soát,
     gập gối, để đôi chân làm việc.

═══════════════════════════════════════════
```

In bảng này ra, để trong túi vợt, và lần tới khi bóng thấp bay tới — hạ người, múc, và trượt nó trở lại qua lưới.
