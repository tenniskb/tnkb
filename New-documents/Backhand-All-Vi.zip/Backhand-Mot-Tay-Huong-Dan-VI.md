# Backhand Một Tay — Hướng Dẫn Toàn Diện

*Lụa, Cây Cung, và Ánh Mắt Tĩnh Lặng*

---

## Chương 1 — Bạn Có Nên Học Cú Đánh Này?

Tôi hay được hỏi câu này bởi các người chơi ngoài 50 tuổi: "Tôi có nên chuyển sang backhand một tay không?"

Đây là câu trả lời trung thực của tôi vào năm 2026: có lẽ không phải để tạo lực. Chắc chắn có, để đánh slice. Và có thể — **có thể** — cho topspin, nhưng chỉ khi vai bạn nói "được" và cái tôi của bạn giữ im lặng.

Bài viết này dành cho ba nhóm người chơi:

1. **Bạn đã đánh backhand một tay** và muốn hoàn thiện nó mà không làm hỏng vai.
2. **Bạn muốn học slice** — phiên bản thanh lịch, ít tải trọng của backhand một tay mà thành thật mà nói, hầu hết người chơi trên 50 tuổi nên sử dụng thường xuyên hơn nhiều so với hiện tại.
3. **Bạn là huấn luyện viên hoặc học viên** muốn hiểu cơ chế sinh học cấp độ chuyên nghiệp được chuyển hóa thành thứ mà người chơi trình 3.5 có thể thực sự áp dụng — điều gì nên học từ Dimitrov, điều gì nên bỏ qua từ Wawrinka, và tại sao "ánh mắt tĩnh" của Federer có thể là cải thiện rẻ nhất mà bạn có thể có.

### Ba Tay Vợt Chuyên Nghiệp, Ba Câu Trả Lời Khác Nhau Cho Cùng Một Vấn Đề

Tôi thích nghiên cứu ba tay vợt chuyên nghiệp khi dạy cú đánh này, vì mỗi người giải quyết cùng một vấn đề theo cách khác nhau, với những đánh đổi khác nhau. Ở trình độ của bạn, bạn không cố trở thành bất kỳ ai trong số họ. Bạn đang chọn lọc những mảnh ghép an toàn cho cơ thể mình.

- **Dimitrov** đánh với một vòng lặp C mượt mà — lực đến từ xoay hông và độ đàn hồi bật ra của vòng lặp đó. Tải trọng vai mức trung bình. Điều bạn nên học: để đầu vợt rơi như lụa thay vì giật nó về phía sau.
- **Wawrinka** bùng nổ và tuyến tính — thân trên xoay mở kết hợp một cú kéo khuỷu tay trái sâu. Tải trọng vai cao, có lẽ cao nhất trong ba người. Điều bạn nên học: học chuyển trọng lượng tuyến tính của anh ấy, bỏ qua hoàn toàn cú kéo khuỷu tay.
- **Federer** gọn gàng và hiệu quả — chính xác, ánh mắt tĩnh, và cánh tay gần như thẳng khi tiếp xúc. Tải trọng thấp đến trung bình. Điều bạn nên học: ánh mắt tĩnh, bước chân gót-tới-mũi, và một cánh tay **gần như** thẳng, không khóa cứng hoàn toàn.

Tôi coi backhand một tay là cú đánh phối hợp nội lực nhất trong tennis — gần với một pha đẩy tay (thôi thủ) trong thái cực quyền hơn bất cứ điều gì khác trong môn thể thao này. Ở cú hai tay, tay không thuận của bạn tạo thêm một động cơ ổn định thứ hai. Ở cú một tay, động cơ thứ hai đó biến mất. Bạn phải xây dựng động cơ từ bên trong — lõi cơ thể xoay, lưng dưới mở ra, ngực bắn cánh tay xuyên qua. Đó là lý do một cú một tay tốt trông thật nhẹ nhàng khi nó đúng. Nó gần như hoàn toàn đến từ lõi cơ thể, không phải cánh tay.

**Cái bẫy lớn nhất ở trình độ của bạn:** cố sao chép phiên bản **cực đoan** của một tay vợt chuyên nghiệp trong pha chuẩn bị — cú xoay cằm chạm vai sâu của Dimitrov, cú kéo khuỷu tay sâu của Wawrinka, cánh tay thẳng tuyệt đối của Federer. Mỗi điều đó tốn của các tay vợt chuyên nghiệp hơn mười nghìn giờ tập luyện và một cơ thể được rèn luyện từ nhỏ để chịu được điều đó. Việc của bạn là lấy phiên bản tối thiểu hiệu quả của mỗi cue và bỏ qua phần cực đoan.

---

## Chương 2 — Grip và Tư Thế Chuẩn Bị

### Grip: Continental, Không Ngoại Lệ

Grip của bạn là Continental. Chấm hết. Chữ V giữa ngón cái và ngón trỏ nằm trên bevel #2 — đúng bevel bạn đã dùng cho volley, slice, và cú giao bóng trên cao.

Tại sao không phải Eastern hay Semi-Western? Vì ở cú một tay, bạn không có bàn tay thứ hai đỡ mặt vợt. Bất cứ thứ gì mở hơn Continental sẽ để mặt vợt mở khi tiếp xúc và bóng sẽ bay quá dài. Continental giữ mặt vợt hơi đóng lại một chút, đúng là những gì bạn cần cho một cú đánh một tay.

**Kiểm tra nhanh:** cầm vợt như đang bắt tay nó. Bây giờ xoay tay nhẹ (ngược chiều kim đồng hồ nếu bạn thuận tay phải) cho đến khi chữ V nằm trên bevel phía trên bên trái. Đó chính là Continental. Gò ngón cái của bạn nên nghỉ dọc theo bevel phía sau.

Một cách kiểm tra khác: hãy tưởng tượng bạn đang đóng đinh xuống mặt sân trước mặt. "Mặt búa" — dây vợt của bạn — nên hướng về phía hàng rào bên, không hướng lên trời. Nếu nó hướng lên trời, grip của bạn đã trôi về phía Eastern. Chỉnh lại trước khi vung.

### Tư Thế Chuẩn Bị: Tay Trên Chỉ Hướng, Không Cầm Vợt

Đây là sự khác biệt lớn nhất về mặt hình ảnh giữa cú một tay và cú hai tay. Ở cú hai tay, cả hai tay đến cùng nhau tạo thành hình thoi ở tầm ngực. Ở cú một tay, tay trên của bạn không bao giờ chạm vào vợt trong pha chuẩn bị. Thay vào đó, nó chỉ có một nhiệm vụ: **chỉ vào bóng.**

Qua pha xoay người, tay trái của bạn (với người thuận tay phải) làm ba việc:

1. **Giúp bắt đầu pha xoay.** Khuỷu tay tụt vào gần hông phải khi vai xoay — vợt được mang về phía sau nhờ pha xoay của vai, không phải do cánh tay kéo nó.
2. **Giữ nguyên vị trí trên cao, chỉ vào bóng.** Ngón trỏ của bạn theo dõi bóng đang bay tới suốt cả pha xoay và vào đầu cú vung. Điều này âm thầm huấn luyện mắt bạn luôn khóa vào bóng.
3. **Buông ra khi bạn vung về phía trước.** Khi cánh tay phải bắt đầu đường vung tới, tay trái vẫn giữ nguyên vị trí cao (hoặc hạ xuống để giữ thăng bằng ở bóng thấp) — nó không dính chặt vào vợt suốt cả cú vung.

Một cách tốt để cảm nhận điều này: đứng nghiêng, vai phải hướng về phía lưới. Đưa vợt lên và ra sau với cánh tay phải gập khoảng 90 độ — hãy nghĩ đến hình chữ "L" từ vai xuống đầu vợt. Cánh tay trái của bạn phản chiếu độ gập đó, tay ở ngang cằm, chỉ vào quả bóng tưởng tượng đang bay đến, khuỷu tay giữ sát người. Nếu bạn đóng băng ở đó, bạn nên trông hơi giống một thủ môn chuẩn bị cản phạt đền.

### Nhịp Điệu: Nhảy Trước, Xoay Sau

Cùng quy tắc với cú thuận tay: split-step trước, xoay người sau. Một cú nhảy nhỏ khi đối thủ tiếp xúc bóng, hai chân tiếp đất rộng bằng vai, và chỉ sau đó pha xoay vai của bạn mới bắt đầu.

Điều này quan trọng hơn ở cú một tay so với cú hai tay. Một pha xoay trễ ở cú hai tay vẫn có thể tạo ra một cú đánh khá tốt vì bàn tay thứ hai cứu bạn. Một pha xoay trễ ở cú một tay thường sẽ dẫn tới đánh hụt, hoặc một cú slice cắm thẳng vào lưới.

Đây là trình tự tôi muốn bạn nghĩ tới: thấy bóng rời khỏi dây vợt của đối thủ, nhảy, xoay vai (cằm hướng về vai phải, vợt ở hình chữ L cao, tay trái chỉ vào bóng), sau đó tập trung mắt vào điểm bạn định tiếp xúc.

**Bài tập — Thiết Lập Trước Gương.** Đứng cách tường hoặc gương một mét. Thực hiện pha xoay người mười lần: nhảy, xoay, hình L, tay trái chỉ. Giữ tư thế trong hai giây. Kiểm tra bản thân mỗi lần — cằm bạn có hướng về vai phải không, đầu vợt có ở trên cao không, tay trái có chỉ vào bóng không, khuỷu trái có được tụt vào không? Ba phút mỗi ngày là đủ để cơ thể tự động hóa tư thế này mà không cần suy nghĩ.

---

## Chương 3 — Điều Gì Thay Đổi Khi Chỉ Có Một Cánh Tay

Cùng khung bốn lớp từ cú thuận tay của bạn — cú vung, tư thế chuẩn bị, trục xoay, và cảm giác — đều áp dụng ở đây, nhưng tải trọng dịch chuyển. Ở cú hai tay, hai cánh tay chia sẻ công việc. Ở cú một tay, tất cả dồn vào vai phải và bên phải của lõi cơ thể bạn. Đó chính xác là lý do các yếu tố xoay và cảm giác quan trọng hơn ở đây, không phải ít hơn.

### Cú Vung: Giữ Hình "L" Đến Khi Tiếp Xúc

Hình chữ "L" gập tay mà bạn dùng ở pha chuẩn bị cú thuận cũng xuất hiện ở đây — góc giữa cẳng tay và cán vợt nên giữ gập gần như cho đến khi tiếp xúc. Hầu hết người chơi trình 3.5 duỗi thẳng cánh tay đó quá sớm ở cú một tay. Đó là cùng sai lầm với "vung bằng cánh tay" ở cú thuận, và nó tạo ra kết quả tương tự: một cú đánh yếu, trễ, dễ chấn thương.

Nhịp 70/30 vẫn áp dụng, có lẽ còn quan trọng hơn ở đây. Bảy mươi phần trăm cú vung là chậm — cú đưa vợt xuống, sự chuẩn bị, để đầu vợt rơi vào vị trí. Ba mươi phần trăm là nhanh — cú bùng nổ từ tiếp xúc đến kết thúc.

Bạn có hai hình dạng chuẩn bị an toàn để lựa chọn:

- **Vòng lặp C (kiểu Dimitrov):** đầu vợt rơi qua một hình "C" lớn, mượt mà bên dưới bóng, với pha xoay người sâu hơn. Trông rất đẹp khi đúng. Rủi ro ở tuổi của bạn là cú xoay cằm chạm vai sâu đó gây tải lên cổ.
- **Slot (kiểu Federer):** gọn gàng hơn — vợt rơi xuống khoảng ngang eo-ngực, hơi sau lưng bạn. Ít xoay vai hơn, ít xoay cổ hơn, canh giờ dễ hơn. **Đây là lựa chọn tôi muốn làm mặc định cho bạn.**

Slot đòi hỏi ít hơn từ vai và cột sống ngực để đạt đến cùng điểm tiếp xúc. Đó chính là toàn bộ triết lý Federer trong một câu: cùng kết quả, ít di chuyển hơn, ít rủi ro hơn. Ở tuổi 50 trở lên, đó là sự khác biệt giữa việc chơi cú đánh này hai lần một tuần trong nhiều năm và việc chơi nó hai lần trước khi vai bạn bảo bạn dừng lại.

**Cú rơi** nên cảm giác như đang rơi, không phải kéo. Từ tư thế hình L đó, chỉ cần để vợt rơi trên cạnh của nó vào slot — đừng chủ động kéo nó xuống. Nếu bạn kéo nó, vai bạn đang làm việc chủ động mỗi lần lặp lại, và đó chính xác là loại tải trọng lặp đi lặp lại dẫn đến va chạm khớp vai. Hãy để trọng lực làm việc thay thế: hãy nghĩ đầu vợt như một tấm lụa rơi trong không khí. Bạn không kéo lụa xuống. Bạn chỉ ngừng giữ nó lên.

Hãy xem cú vòng lặp C của Dimitrov ở chế độ quay chậm — không có cú giật nào ở đáy của cú rơi. Đầu vợt chạm điểm thấp nhất, dừng lại trong một khoảnh khắc, rồi bắn về phía trước. Khoảnh khắc dừng đó chính là sự tích lũy năng lượng, giống như một cây roi được kéo về sau trước khi vụt ra.

### Sự Xoay: Để Hông Dẫn Dắt, Không Phải Cổ

Hãy nghĩ cột sống của bạn như một bản lề cửa, không phải một cái thùng đang xoay tại chỗ. Ở cú một tay, sự xoay của bạn tự nhiên lớn hơn ở cú hai tay, vì không có cánh tay thứ hai giới hạn nó. Rủi ro là bạn xoay quá mức phần cột sống trên và cổ thay vì hông.

Thứ tự quan trọng: hông xoay trước, ngực theo sau, vai theo sau ngực, cánh tay theo sau vai. Mỗi phần chỉ bắt đầu di chuyển **sau khi** phần bên dưới nó đã bắt đầu. Từ dưới lên trên, luôn luôn.

Với người thuận tay phải, bên trái trở thành bên ổn định, vững chãi của bạn ở cú đánh này, và bên phải là bên tự do di chuyển. Chân phải của bạn hoạt động như một chân chống — nó bước vào trong khi chân trái xoay và ngực bạn mở ra.

Có một cảm giác tôi muốn bạn cảm nhận ở lưng dưới trong pha chuẩn bị — một sự mở ra, một sự giãn nở ở lưng dưới khi hông tải vào pha xoay. Hầu hết người chơi ở trình độ của bạn giữ lưng dưới cứng và cố tạo toàn bộ sự xoay ở cổ và vai thay vào đó. Việc để lưng dưới mở ra khi lùi lại, rồi đóng lại khi bạn vung xuyên qua, chính là điều thực sự tạo ra sự tách biệt giữa hông và vai giúp tạo ra tốc độ vợt thực sự — mà không cần cổ phải làm điều gì kịch tính.

### Cảm Giác: Ánh Mắt Tĩnh Lặng Giúp Bạn Thắng Trận

Đây là một thói quen của Federer không tốn gì để sao chép và đáng giá hơn hầu hết mọi thứ khác trong danh sách này: sau khi tiếp xúc, giữ mắt của bạn ở điểm tiếp xúc trong khoảng hai phần mười giây. Đầu bạn hầu như không di chuyển.

Tại sao nó hiệu quả — 200 mili giây đó cho não bạn thêm thời gian để xử lý chính xác điều vừa xảy ra: bạn tiếp xúc ở đâu, bóng bật ra khỏi dây vợt như thế nào, timing của bạn sớm hay trễ. Vòng phản hồi đó chính là thứ khiến cú đánh tiếp theo của bạn tốt hơn. Nó miễn phí. Nó chỉ đòi hỏi sự kiên nhẫn mà bạn không quen dành cho bản thân.

**Trong tập luyện** (không bao giờ trong trận đấu), hãy thử điều này: sau mỗi cú đánh tốt, đóng băng động tác theo bóng và đếm "một Mississippi, hai Mississippi" trước khi di chuyển lại. Khoảng dừng hai giây đó khóa cảm giác của vị trí đúng vào cơ thể bạn, không chỉ vào trí nhớ về hình ảnh của nó.

**Bài tập — Cấp Bóng với Ánh Mắt Tĩnh.** Nhờ một người bạn cấp cho bạn mười quả bóng. Việc duy nhất của bạn là đánh, đóng băng động tác theo bóng, đếm đến hai, rồi xoay người để theo dõi quả bóng tiếp theo. Sau mười lần, đổi lại — đánh và xoay đầu ngay lập tức để theo dõi quả bóng kế tiếp. Bạn sẽ cảm nhận sự khác biệt ngay lập tức. Phiên bản đầu cảm giác chậm hơn. Nó cũng tạo ra tiếp xúc sạch hơn, gần như mỗi lần.

---

## Chương 4 — Ba Tay Vợt Chuyên Nghiệp, Điều Gì Nên Học Và Điều Gì Nên Bỏ

Đây là nơi hầu hết người chơi ở trình độ của bạn mắc sai lầm. Họ xem một tay vợt chuyên nghiệp trên TV, chọn người mình yêu thích, và cố sao chép phiên bản cực đoan nhất của cú đánh đó. Dưới đây là bản dịch — điều gì thực sự đáng để học từ mỗi người, và điều gì nên để yên.

### Dimitrov — Người Nghệ Sĩ Mượt Mà

Đặc trưng của anh: đầu vợt được đưa lên cao, thường trên đầu, rồi rơi qua một hình chữ "C" lớn bên dưới bóng. Pha chuẩn bị của anh sâu — cằm gần như chạm vai phải — và điểm tiếp xúc ở phía trước xa với cánh tay gần như duỗi thẳng. Lực đến từ xoay hông, cú "quất" của vai, và độ đàn hồi bật ra của vòng lặp C đó. Trên các cú đánh cưỡng bức, anh thường hạ trọng tâm rất sâu, đầu gối phải gần chạm mặt sân.

**Học:** cue "cú rơi vòng lặp C" — để đầu vợt rơi như lụa, rồi tăng tốc qua bóng. Đây là cue dễ sao chép nhất từ một tay vợt chuyên nghiệp. Ngay cả ở trình 3.5, để đầu vợt rơi theo hình chữ C (không kéo nó về sau) làm giảm tải vai và thêm tốc độ vợt. Cũng hãy học khoảng dừng ở đáy của cú rơi — đừng vội, khoảng dừng đó chính là sự tích lũy.

**Bỏ qua:** cú xoay người với cằm chạm vai sâu (đó là tải trọng thực sự lên cổ ở tuổi của bạn — xoay vai, nhưng giữ cằm gần trung tính hơn) và cú gập gối rất sâu trên mỗi cú đánh (dành nó cho quả bóng buộc bạn phải với rộng ra; một tư thế thể thao bình thường là đủ trên một quả bóng trung tính).

Hãy thử cảm giác này: cầm vợt ra trước mặt, mặt vợt hướng lên, chỉ tay phải. Để đầu vợt rơi — đừng kéo nó, chỉ cần thả lỏng những cơ đang giữ nó lên. Quan sát nó rơi trên cạnh, mô tả một cung tròn. Đó chính là vòng lặp C, tại cổ tay. Cổ tay lỏng, đầu vợt rơi theo trọng lượng của chính nó, ngực bạn bắt lấy nó ở đáy và đẩy nó về phía trước.

### Wawrinka — Cỗ Máy Bùng Nổ

Đặc trưng của anh: chuẩn bị sớm và tích cực, một cú kéo khuỷu tay trái sâu ra sau lưng, và chuyển trọng lượng tuyến tính với chân trước hướng khoảng 45 độ so với lưới. Lực đến từ sự xoay mở của thân trên — cú kéo khuỷu tay trái của Wawrinka tạo ra đường vợt rộng và pha xoay vai bị trễ. Năng lượng tích lũy trong khuỷu tay trái sâu cộng với cuộn thân trên được giải phóng khi hông và vai mở ra theo trình tự. Đó chính là cú đánh khiến biệt danh "Stanimal" ra đời, và bạn có thể nghe thấy nó — một âm thanh tiếp xúc đặc trưng, mạnh mẽ là sản phẩm của toàn bộ chuỗi động học bùng nổ cùng lúc.

**Cảnh báo trước tiên:** theo tôi, cú kéo khuỷu tay trái sâu đó là động tác gây căng thẳng cho vai nhất được đề cập trong toàn bộ hướng dẫn này. Wawrinka cao 1m90, và anh đã đánh theo cách này từ năm 12 tuổi — vai và cột sống ngực của anh đã được rèn luyện cho tải trọng đó suốt hàng chục năm. Ở tuổi 50 trở lên, cùng động tác đó đưa vai bạn vào xoay ngoài và dạng cực đoan, gây căng cơ chóp xoay, làm căng lưng trên, và gây tải lên lưng dưới. Bỏ qua nó. Hoàn toàn.

**Thay vào đó, học:** chuyển trọng lượng tuyến tính — chân trước bước vào theo một góc, trọng lượng dồn về phía trước, chân sau đẩy khỏi mặt sân. Điều này hoàn toàn an toàn và rất hữu ích; nó đưa cơ thể bạn **vào** cú đánh thay vì chỉ xoay tại chỗ. Cũng hãy học chuẩn bị sớm — xoay sớm, đánh trễ, vì backhand một tay có biên độ sai số nhỏ hơn cú hai tay và bạn cần sẵn sàng trước khi bóng đến. Một góc chân trước vừa phải (20-30 độ là đủ, bạn không cần đủ 45 độ) giúp hông bạn mở đủ để ngực xoay tự do.

### Federer — Sự Hiệu Quả Không Tốn Sức

Đặc trưng của anh: pha chuẩn bị gọn gàng vào cái gọi là vị trí slot, một cánh tay gần như thẳng khi tiếp xúc, một bước gót-tới-mũi vào sân, và sự ổn định đầu đáng kinh ngạc sau khi bóng rời dây vợt. Tốc độ vợt của anh khi tiếp xúc thực ra thấp hơn Dimitrov hoặc Wawrinka — nhưng điểm tiếp xúc của anh nhất quán hơn, độ chính xác đặt bóng sắc bén hơn, và sự hiệu quả của anh là điều giúp anh duy trì cú đánh này suốt một trận đấu năm tiếng.

**Học gần như tất cả.** Pha chuẩn bị slot gọn gàng là phiên bản tối thiểu hiệu quả của cú đánh này — ít di chuyển hơn, ít tải vai hơn, canh giờ dễ hơn, và tôi muốn nó là lựa chọn mặc định hàng ngày của bạn. Bước gót-tới-mũi là footwork an toàn nhất bạn có thể dùng — nhỏ, có kiểm soát, tải dần dần qua đầu gối, không lao người. Ánh mắt tĩnh, như đã nói ở trên, là cải thiện rẻ nhất có sẵn cho bạn. Và tư duy tổng thể — làm ít hơn, không phải nhiều hơn, và để việc đặt bóng làm việc thay vì tốc độ vợt thô — đáng để học trọn vẹn.

**Một điều chỉnh:** bỏ qua cánh tay thẳng hoàn toàn. Điều đó tốn của Federer hơn hai mươi lăm năm rèn luyện. Thay vào đó, dùng 15 đến 20 độ gập khuỷu tay — bạn mất một lượng nhỏ đòn bẩy và đạt được một lượng lớn hơn nhiều sự an toàn cho vai. Đây là một sự đánh đổi dễ dàng.

**Bài tập — Slot Kiểu Federer.** Đứng ở vạch cuối sân, không có bóng. Đưa vợt về vị trí slot: đầu vợt thấp hơn nơi bóng sẽ đến, mặt vợt hơi đóng, cánh tay phải gập khoảng 90 độ, tay trái chỉ. Giữ trong hai giây và kiểm tra bản thân. Sau đó vung về phía trước chậm rãi, để khuỷu tay bạn ổn định ở mức gập 15-20 độ khi bạn tới vùng tiếp xúc — không thẳng, không gập quá sâu. Kết thúc trên vai phải, đóng băng, và đếm đến hai.

---

## Chương 5 — Slice: Người Bạn Tốt Nhất Của Vai Bạn

Nếu chỉ có một phiên bản của backhand một tay mà mỗi người chơi trên 50 tuổi nên sở hữu, bất kể lịch sử vai, đó chính là slice. Cùng grip với volley của bạn, một chuyển động cao xuống thấp, và độ xoáy dưới giúp bạn có thêm thời gian, phá vỡ nhịp điệu, và hoạt động tuyệt vời trong phòng thủ, bóng thấp, cú tiếp cận lưới, và trả các cú giao bóng mạnh.

### Nó Khác Với Topspin Một Tay Ở Điểm Nào

Slice chia sẻ grip với backhand topspin một tay nhưng gần như không có gì khác về chuyển động. Trong khi pha chuẩn bị topspin đưa đầu vợt lên trước khi rơi vào slot hoặc vòng lặp C, pha chuẩn bị slice đi **cao** — trên vai bạn. Trong khi topspin vung thấp-lên-cao, slice vung cao-xuống-thấp. Tiếp xúc xảy ra khoảng ngang eo trên đường xuống, mặt vợt mở như mui xe — 30 đến 45 độ — thay vì đóng lại. Cổ tay của bạn giữ khóa suốt toàn bộ động tác; không có sự sấp cổ tay như ở phía topspin. Và trong khi topspin đòi hỏi vai bạn hấp thụ toàn bộ chuỗi động học, slice hầu như không đòi hỏi gì từ nó — cú vung ngắn và chủ yếu đi xuống, được cung cấp lực bởi trọng lượng cơ thể chuyển về phía trước và trọng lực, không phải cánh tay bạn.

Đó thực sự là điểm mấu chốt: **ở slice, lực đến từ trọng lực và chuyển trọng lượng, không phải cánh tay bạn.** Pha chuẩn bị cao tích lũy năng lượng thế năng; cú vung giải phóng nó. Cánh tay bạn chỉ đưa vợt đi, không tạo ra lực. Đó chính xác là lý do nó nhẹ nhàng hơn nhiều với vai so với phiên bản topspin, nơi vai làm hầu hết công việc xoay trong một phần giây.

Tôi thích mô tả toàn bộ chuyển động như một cánh cửa: pha chuẩn bị là cánh cửa mở ra — đầu vợt lên cao, cánh tay bạn mở ra, cơ thể bạn bắt đầu xoay. Cú vung là cánh cửa đóng lại — vợt đi xuống và ngang qua cơ thể bạn, mặt vợt giữ mở, tiếp xúc xảy ra ở đâu đó giữa cung đó. Và khi tiếp xúc xảy ra, bạn đang bước qua cánh cửa — trọng lượng của bạn chuyển về phía trước, chân trước bạn cắm xuống, vai bạn xoay xuyên qua. Kết quả là một quả bóng có độ xoáy dưới và một chút xoáy ngang trôi nhẹ về phía trước, rồi giữ thấp sau khi nảy.

Hoặc hãy nghĩ về một cần gạt nước kính chắn gió — điểm cao ở một đầu, kết thúc thấp ở đầu kia, mặt vợt nghiêng suốt cả đường đi, tiếp xúc xảy ra khi nó đi qua điểm giữa.

### Khi Nào Nên Dùng Nó

- **Dưới áp lực, phòng thủ:** chỉ cần đưa nó trở lại sâu. Mua thời gian cho bản thân để hồi vị trí.
- **Làm cú tiếp cận lưới:** slice thấp khi bạn tiến lên — một quả bóng thấp buộc đối thủ vào một cú slice hoặc lốp khó chịu của riêng họ.
- **Trả một cú giao bóng mạnh:** độ xoáy dưới hấp thụ lực và bóng rơi ngắn. Đây là bạn của bạn trên bất kỳ cú giao bóng nào bạn không thể áp đảo được.
- **Phá vỡ nhịp điệu:** chèn một cú slice sau một chuỗi rally topspin. Sự thay đổi độ xoáy làm rối timing của đối thủ nhiều hơn bạn tưởng.

**Bài tập — Rally Tường Slice.** Đứng cách tường khoảng 4 mét. Rally chỉ với slice, nhịp độ chậm, và nhắm tới 20 cú liên tiếp nảy dưới tầm eo bên phía bạn. Lắng nghe âm thanh — một cú slice sạch phát ra tiếng "fwoosh" nhẹ nhàng. Một tiếng cứng hơn, "thwack", nghĩa là bạn đánh phẳng, không phải xoáy dưới. Chỉnh sửa và thử lại.

Một lưu ý nữa: đánh cú này chỉ với tay phải — không có tay trái trên vợt, khác với slice hai tay. Hầu hết người chơi trên 50 tuổi thấy tay trái tự do thực sự giúp giữ thăng bằng qua cú đánh.

---

## Chương 6 — Bài Tập, Lỗi Thường Gặp, Chăm Sóc Vai, và Bảng Tóm Tắt Của Bạn

### Bảy Bài Tập Để Đưa Vào Tuần Của Bạn

1. **Thiết Lập Trước Gương** — hàng ngày, 3 phút. Mười lần lặp pha xoay người trước tường hoặc gương, giữ mỗi lần trong 2 giây. Kiểm tra cằm, đầu vợt, tay chỉ, và khuỷu tay tụt vào.
2. **Rơi Như Lụa** — hàng ngày, 5 phút. Đưa vợt lên và ra sau, rồi chỉ để nó rơi vào vị trí slot thay vì kéo nó. Dừng ở đáy, rồi vung về phía trước chậm rãi. Hai mươi lần lặp.
3. **Ánh Mắt Tĩnh + Dừng Hai Giây** — hàng tuần, trên sân. Mười quả bóng được cấp, đóng băng động tác theo bóng và đếm đến hai sau mỗi cú đánh.
4. **Shadow Slot + Gót-Mũi** — hàng ngày, 5 phút. Cú vung không bóng ở vạch cuối sân tập trung vào pha chuẩn bị slot gọn gàng và bước gót trước vào cú đánh. Hai mươi lần lặp.
5. **Rally Tường Slice** — 3 lần một tuần, 10 phút. Hai mươi cú slice liên tiếp rơi dưới tầm eo bên ngoài tường.
6. **So Sánh Vòng Lặp C vs Slot** — hàng tuần, 10 phút. Mười quả bóng với mỗi pha chuẩn bị, liên tiếp nhau, cảm nhận sự đánh đổi giữa tốc độ vợt và tải vai. Hướng tới việc đánh slot khoảng 80% thời gian.
7. **Kiểm Tra Mở Lưng Dưới** — hàng ngày, 3 phút. Pha chuẩn bị với cả hai tay trên vợt, chủ động cảm nhận lưng dưới mở ra khi hông phải xoay về sau và hông trái giữ nguyên phía trước. Bạn đang luyện tập cảm giác, không phải một chuyển động lớn có thể nhìn thấy.

### Bảy Lỗi Tôi Thấy Liên Tục Ở Trình Độ Của Bạn

| Lỗi | Trông như thế nào | Cách sửa |
|---|---|---|
| Sai grip | Eastern hoặc Semi-Western — mặt vợt mở khi tiếp xúc | Continental, V trên bevel #2 |
| Kéo pha chuẩn bị | Vợt bị giật về sau thay vì được thả rơi | Cue rơi như lụa — để trọng lực làm việc |
| Kéo khuỷu tay sâu | Khuỷu trái quá sâu ra sau lưng, vai quá tải | Vị trí slot, khuỷu tay giữ sát người |
| Cánh tay thẳng hoàn toàn khi tiếp xúc | Khuỷu tay khóa cứng, đau vai sau đó | 15-20 độ gập khuỷu tay |
| Pha xoay nông | Nhỏ hơn hoặc trễ hơn pha xoay cú thuận | "Nhảy, rồi xoay" — kiểm tra trong gương |
| Vung bằng cánh tay | Ngực đứng yên, cánh tay làm hết việc | "Ngực xoay, cánh tay theo sau" |
| Không có ánh mắt tĩnh | Đầu quay ngay sau khi tiếp xúc | Luyện tập đếm hai giây |

### Chăm Sóc Vai, Riêng Cho Bạn

- **Rủi ro va chạm vai:** chủ yếu đến từ tải trọng topspin một tay lặp đi lặp lại. Nếu đây là một mối lo ngại, hãy dựa vào slice cho bất cứ điều gì không phải là một quả bóng sạch, dễ đánh, và dùng cú hai tay cho các tình huống cần lực.
- **Căng cơ chóp xoay:** thường xuất phát từ cú kéo khuỷu tay sâu hoặc pha chuẩn bị quá rộng. Vị trí slot và footwork gót-tới-mũi là sự bảo vệ của bạn ở đây.
- **Căng cổ và lưng trên:** đến từ pha xoay cằm chạm vai sâu. Để vai bạn xoay đầy đủ, nhưng giữ đầu gần trung tính hơn.
- **Đau lưng dưới:** thường có nghĩa là lưng dưới của bạn không mở ra trong pha chuẩn bị — nó vẫn cứng và chuyển tải trọng đến nơi không nên. Bài tập kiểm tra lưng dưới ở trên giải quyết trực tiếp điều này.
- **Tin tốt về khuỷu tay:** cú một tay thực ra nhẹ nhàng hơn cú hai tay đối với cánh tay không thuận của bạn, vì nó hoàn toàn không cầm vợt trong cú vung.

Nếu bạn đang quản lý một vấn đề vai hiện có — đặc biệt bất cứ điều gì liên quan đến va chạm khớp hoặc phẫu thuật trước đó — hãy dựa gần như hoàn toàn vào slice, dùng cú hai tay cho lực, và coi backhand topspin một tay là cú đánh thỉnh thoảng, không phải chủ lực.

**Quy tắc duy nhất tôi muốn bạn nhớ hơn mọi thứ khác trong hướng dẫn này:** slice là cú đánh bạn có thể thực hiện mỗi ngày. Backhand topspin một tay là một điều xa xỉ nhiều nhất một lần một tuần. Và cú kéo khuỷu tay của Wawrinka hoàn toàn không dành cho bạn. Hãy hỏi vai bạn trước khi hỏi cái tôi của bạn.

---

## Bảng Tóm Tắt Nhanh

```
═══════════════════════════════════════════════════════════════
  BACKHAND MỘT TAY — TÓM TẮT NHANH
═══════════════════════════════════════════════════════════════

  Ý TƯỞNG LỚN
  Hãy hỏi vai bạn, không phải cái tôi.
  Slice = dùng hàng ngày. Topspin = xa xỉ một lần/tuần. Cú kéo
  khuỷu tay của Wawrinka = không dành cho bạn.

  ───────────────────────────────────────────────────────────
  QUYẾT ĐỊNH
  ───────────────────────────────────────────────────────────
  Vai khỏe mạnh, nhiều năm kinh nghiệm    → Cue kiểu Federer
  Hơi cứng                                → Chỉ slice
  Có tiền sử va chạm khớp                 → 2HB cho lực, chỉ slice

  ───────────────────────────────────────────────────────────
  GRIP
  ───────────────────────────────────────────────────────────
  Continental — V trên bevel #2, giống volley

  ───────────────────────────────────────────────────────────
  TƯ THẾ CHUẨN BỊ
  ───────────────────────────────────────────────────────────
  Nhảy (split-step) khi đối thủ tiếp xúc bóng
  Tay trên chỉ vào bóng, không cầm vợt
  Pha chuẩn bị hình L, đầu vợt lên cao
  Cằm hướng vai, nhưng giữ gần trung tính
  Khuỷu trái tụt vào hông, không ra sau lưng

  ───────────────────────────────────────────────────────────
  CÚ VUNG TOPSPIN
  ───────────────────────────────────────────────────────────
  Pha chuẩn bị: SLOT (Federer), không phải vòng lặp C sâu
  Cú rơi: vợt rơi trên cạnh, như lụa
  Dừng ở đáy — đó là sự tích lũy
  70% chậm, 30% nhanh
  Tiếp xúc phía trước chân trước
  Khuỷu tay gập 15-20° — không khóa thẳng
  Kết thúc trên vai phải, ánh mắt tĩnh 0.2 giây

  ───────────────────────────────────────────────────────────
  SLICE
  ───────────────────────────────────────────────────────────
  Cùng grip, pha chuẩn bị CAO ("cửa mở")
  Đường vung: CAO xuống THẤP ("cửa đóng")
  Mặt vợt mở như mui xe, 30-45°
  Tiếp xúc ngang eo, trên đường xuống
  Kết thúc thấp, ngang qua cơ thể
  Tay mềm, tiếp xúc chắc — lắng nghe tiếng "fwoosh"

  ───────────────────────────────────────────────────────────
  BA TAY VỢT CHUYÊN NGHIỆP — HỌC CÁI NÀY, BỎ CÁI KIA
  ───────────────────────────────────────────────────────────
  Dimitrov  → Học: cú rơi như lụa
            → Bỏ: pha xoay cằm chạm vai sâu

  Wawrinka  → Học: chuyển trọng lượng tuyến tính
            → Bỏ: cú kéo khuỷu tay sâu (rủi ro chấn thương lớn nhất)

  Federer   → Học: slot, gót-tới-mũi, ánh mắt tĩnh
            → Bỏ: cánh tay thẳng hoàn toàn

  ───────────────────────────────────────────────────────────
  DỪNG LẠI VÀ ĐIỀU CHỈNH NẾU
  ───────────────────────────────────────────────────────────
  • Đau vai trong hoặc sau backhand topspin một tay
  • Đau khuỷu tay ở cánh tay thuận
  • Cứng cổ sau các buổi tập backhand
  • Đau lưng dưới (lưng dưới không mở ra)
  • Đau cổ tay khi tiếp xúc

═══════════════════════════════════════════════════════════════
```

In bảng tóm tắt ra, giữ nó trong túi vợt, và nhớ quy tắc quan trọng hơn bất kỳ cue nào ở đây: hãy hỏi vai bạn, không phải cái tôi.
